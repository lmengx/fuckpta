(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=((n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n)))(o(((e,t)=>{var n=function(e){var t=/(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i,n=0,r={},i={manual:e.Prism&&e.Prism.manual,disableWorkerMessageHandler:e.Prism&&e.Prism.disableWorkerMessageHandler,util:{encode:function e(t){return t instanceof a?new a(t.type,e(t.content),t.alias):Array.isArray(t)?t.map(e):t.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/\u00a0/g,` `)},type:function(e){return Object.prototype.toString.call(e).slice(8,-1)},objId:function(e){return e.__id||Object.defineProperty(e,`__id`,{value:++n}),e.__id},clone:function e(t,n){n||={};var r,a;switch(i.util.type(t)){case`Object`:if(a=i.util.objId(t),n[a])return n[a];for(var o in r={},n[a]=r,t)t.hasOwnProperty(o)&&(r[o]=e(t[o],n));return r;case`Array`:return a=i.util.objId(t),n[a]?n[a]:(r=[],n[a]=r,t.forEach(function(t,i){r[i]=e(t,n)}),r);default:return t}},getLanguage:function(e){for(;e;){var n=t.exec(e.className);if(n)return n[1].toLowerCase();e=e.parentElement}return`none`},setLanguage:function(e,n){e.className=e.className.replace(RegExp(t,`gi`),``),e.classList.add(`language-`+n)},currentScript:function(){if(typeof document>`u`)return null;if(document.currentScript&&document.currentScript.tagName===`SCRIPT`)return document.currentScript;try{throw Error()}catch(r){var e=(/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(r.stack)||[])[1];if(e){var t=document.getElementsByTagName(`script`);for(var n in t)if(t[n].src==e)return t[n]}return null}},isActive:function(e,t,n){for(var r=`no-`+t;e;){var i=e.classList;if(i.contains(t))return!0;if(i.contains(r))return!1;e=e.parentElement}return!!n}},languages:{plain:r,plaintext:r,text:r,txt:r,extend:function(e,t){var n=i.util.clone(i.languages[e]);for(var r in t)n[r]=t[r];return n},insertBefore:function(e,t,n,r){r||=i.languages;var a=r[e],o={};for(var s in a)if(a.hasOwnProperty(s)){if(s==t)for(var c in n)n.hasOwnProperty(c)&&(o[c]=n[c]);n.hasOwnProperty(s)||(o[s]=a[s])}var l=r[e];return r[e]=o,i.languages.DFS(i.languages,function(t,n){n===l&&t!=e&&(this[t]=o)}),o},DFS:function e(t,n,r,a){a||={};var o=i.util.objId;for(var s in t)if(t.hasOwnProperty(s)){n.call(t,s,t[s],r||s);var c=t[s],l=i.util.type(c);l===`Object`&&!a[o(c)]?(a[o(c)]=!0,e(c,n,null,a)):l===`Array`&&!a[o(c)]&&(a[o(c)]=!0,e(c,n,s,a))}}},plugins:{},highlightAll:function(e,t){i.highlightAllUnder(document,e,t)},highlightAllUnder:function(e,t,n){var r={callback:n,container:e,selector:`code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code`};i.hooks.run(`before-highlightall`,r),r.elements=Array.prototype.slice.apply(r.container.querySelectorAll(r.selector)),i.hooks.run(`before-all-elements-highlight`,r);for(var a=0,o;o=r.elements[a++];)i.highlightElement(o,t===!0,r.callback)},highlightElement:function(t,n,r){var a=i.util.getLanguage(t),o=i.languages[a];i.util.setLanguage(t,a);var s=t.parentElement;s&&s.nodeName.toLowerCase()===`pre`&&i.util.setLanguage(s,a);var c={element:t,language:a,grammar:o,code:t.textContent};function l(e){c.highlightedCode=e,i.hooks.run(`before-insert`,c),c.element.innerHTML=c.highlightedCode,i.hooks.run(`after-highlight`,c),i.hooks.run(`complete`,c),r&&r.call(c.element)}if(i.hooks.run(`before-sanity-check`,c),s=c.element.parentElement,s&&s.nodeName.toLowerCase()===`pre`&&!s.hasAttribute(`tabindex`)&&s.setAttribute(`tabindex`,`0`),!c.code){i.hooks.run(`complete`,c),r&&r.call(c.element);return}if(i.hooks.run(`before-highlight`,c),!c.grammar){l(i.util.encode(c.code));return}if(n&&e.Worker){var u=new Worker(i.filename);u.onmessage=function(e){l(e.data)},u.postMessage(JSON.stringify({language:c.language,code:c.code,immediateClose:!0}))}else l(i.highlight(c.code,c.grammar,c.language))},highlight:function(e,t,n){var r={code:e,grammar:t,language:n};if(i.hooks.run(`before-tokenize`,r),!r.grammar)throw Error(`The language "`+r.language+`" has no grammar.`);return r.tokens=i.tokenize(r.code,r.grammar),i.hooks.run(`after-tokenize`,r),a.stringify(i.util.encode(r.tokens),r.language)},tokenize:function(e,t){var n=t.rest;if(n){for(var r in n)t[r]=n[r];delete t.rest}var i=new c;return l(i,i.head,e),s(e,i,t,i.head,0),d(i)},hooks:{all:{},add:function(e,t){var n=i.hooks.all;n[e]=n[e]||[],n[e].push(t)},run:function(e,t){var n=i.hooks.all[e];if(!(!n||!n.length))for(var r=0,a;a=n[r++];)a(t)}},Token:a};e.Prism=i;function a(e,t,n,r){this.type=e,this.content=t,this.alias=n,this.length=(r||``).length|0}a.stringify=function e(t,n){if(typeof t==`string`)return t;if(Array.isArray(t)){var r=``;return t.forEach(function(t){r+=e(t,n)}),r}var a={type:t.type,content:e(t.content,n),tag:`span`,classes:[`token`,t.type],attributes:{},language:n},o=t.alias;o&&(Array.isArray(o)?Array.prototype.push.apply(a.classes,o):a.classes.push(o)),i.hooks.run(`wrap`,a);var s=``;for(var c in a.attributes)s+=` `+c+`="`+(a.attributes[c]||``).replace(/"/g,`&quot;`)+`"`;return`<`+a.tag+` class="`+a.classes.join(` `)+`"`+s+`>`+a.content+`</`+a.tag+`>`};function o(e,t,n,r){e.lastIndex=t;var i=e.exec(n);if(i&&r&&i[1]){var a=i[1].length;i.index+=a,i[0]=i[0].slice(a)}return i}function s(e,t,n,r,c,d){for(var f in n)if(!(!n.hasOwnProperty(f)||!n[f])){var p=n[f];p=Array.isArray(p)?p:[p];for(var m=0;m<p.length;++m){if(d&&d.cause==f+`,`+m)return;var h=p[m],g=h.inside,_=!!h.lookbehind,v=!!h.greedy,y=h.alias;if(v&&!h.pattern.global){var b=h.pattern.toString().match(/[imsuy]*$/)[0];h.pattern=RegExp(h.pattern.source,b+`g`)}for(var x=h.pattern||h,S=r.next,C=c;S!==t.tail&&!(d&&C>=d.reach);C+=S.value.length,S=S.next){var w=S.value;if(t.length>e.length)return;if(!(w instanceof a)){var T=1,E;if(v){if(E=o(x,C,e,_),!E||E.index>=e.length)break;var D=E.index,O=E.index+E[0].length,k=C;for(k+=S.value.length;D>=k;)S=S.next,k+=S.value.length;if(k-=S.value.length,C=k,S.value instanceof a)continue;for(var A=S;A!==t.tail&&(k<O||typeof A.value==`string`);A=A.next)T++,k+=A.value.length;T--,w=e.slice(C,k),E.index-=C}else if(E=o(x,0,w,_),!E)continue;var D=E.index,j=E[0],M=w.slice(0,D),N=w.slice(D+j.length),P=C+w.length;d&&P>d.reach&&(d.reach=P);var F=S.prev;M&&(F=l(t,F,M),C+=M.length),u(t,F,T);var I=new a(f,g?i.tokenize(j,g):j,y,j);if(S=l(t,F,I),N&&l(t,S,N),T>1){var L={cause:f+`,`+m,reach:P};s(e,t,n,S.prev,C,L),d&&L.reach>d.reach&&(d.reach=L.reach)}}}}}}function c(){var e={value:null,prev:null,next:null},t={value:null,prev:e,next:null};e.next=t,this.head=e,this.tail=t,this.length=0}function l(e,t,n){var r=t.next,i={value:n,prev:t,next:r};return t.next=i,r.prev=i,e.length++,i}function u(e,t,n){for(var r=t.next,i=0;i<n&&r!==e.tail;i++)r=r.next;t.next=r,r.prev=t,e.length-=i}function d(e){for(var t=[],n=e.head.next;n!==e.tail;)t.push(n.value),n=n.next;return t}if(!e.document)return e.addEventListener&&(i.disableWorkerMessageHandler||e.addEventListener(`message`,function(t){var n=JSON.parse(t.data),r=n.language,a=n.code,o=n.immediateClose;e.postMessage(i.highlight(a,i.languages[r],r)),o&&e.close()},!1)),i;var f=i.util.currentScript();f&&(i.filename=f.src,f.hasAttribute(`data-manual`)&&(i.manual=!0));function p(){i.manual||i.highlightAll()}if(!i.manual){var m=document.readyState;m===`loading`||m===`interactive`&&f&&f.defer?document.addEventListener(`DOMContentLoaded`,p):window.requestAnimationFrame?window.requestAnimationFrame(p):window.setTimeout(p,16)}return i}(typeof window<`u`?window:typeof WorkerGlobalScope<`u`&&self instanceof WorkerGlobalScope?self:{});t!==void 0&&t.exports&&(t.exports=n),typeof global<`u`&&(global.Prism=n),n.languages.markup={comment:{pattern:/<!--(?:(?!<!--)[\s\S])*?-->/,greedy:!0},prolog:{pattern:/<\?[\s\S]+?\?>/,greedy:!0},doctype:{pattern:/<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,greedy:!0,inside:{"internal-subset":{pattern:/(^[^\[]*\[)[\s\S]+(?=\]>$)/,lookbehind:!0,greedy:!0,inside:null},string:{pattern:/"[^"]*"|'[^']*'/,greedy:!0},punctuation:/^<!|>$|[[\]]/,"doctype-tag":/^DOCTYPE/i,name:/[^\s<>'"]+/}},cdata:{pattern:/<!\[CDATA\[[\s\S]*?\]\]>/i,greedy:!0},tag:{pattern:/<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,greedy:!0,inside:{tag:{pattern:/^<\/?[^\s>\/]+/,inside:{punctuation:/^<\/?/,namespace:/^[^\s>\/:]+:/}},"special-attr":[],"attr-value":{pattern:/=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,inside:{punctuation:[{pattern:/^=/,alias:`attr-equals`},{pattern:/^(\s*)["']|["']$/,lookbehind:!0}]}},punctuation:/\/?>/,"attr-name":{pattern:/[^\s>\/]+/,inside:{namespace:/^[^\s>\/:]+:/}}}},entity:[{pattern:/&[\da-z]{1,8};/i,alias:`named-entity`},/&#x?[\da-f]{1,8};/i]},n.languages.markup.tag.inside[`attr-value`].inside.entity=n.languages.markup.entity,n.languages.markup.doctype.inside[`internal-subset`].inside=n.languages.markup,n.hooks.add(`wrap`,function(e){e.type===`entity`&&(e.attributes.title=e.content.replace(/&amp;/,`&`))}),Object.defineProperty(n.languages.markup.tag,`addInlined`,{value:function(e,t){var r={};r[`language-`+t]={pattern:/(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,lookbehind:!0,inside:n.languages[t]},r.cdata=/^<!\[CDATA\[|\]\]>$/i;var i={"included-cdata":{pattern:/<!\[CDATA\[[\s\S]*?\]\]>/i,inside:r}};i[`language-`+t]={pattern:/[\s\S]+/,inside:n.languages[t]};var a={};a[e]={pattern:RegExp(`(<__[^>]*>)(?:<!\\[CDATA\\[(?:[^\\]]|\\](?!\\]>))*\\]\\]>|(?!<!\\[CDATA\\[)[\\s\\S])*?(?=<\\/__>)`.replace(/__/g,function(){return e}),`i`),lookbehind:!0,greedy:!0,inside:i},n.languages.insertBefore(`markup`,`cdata`,a)}}),Object.defineProperty(n.languages.markup.tag,`addAttribute`,{value:function(e,t){n.languages.markup.tag.inside[`special-attr`].push({pattern:RegExp(`(^|["'\\s])(?:`+e+`)\\s*=\\s*(?:"[^"]*"|'[^']*'|[^\\s'">=]+(?=[\\s>]))`,`i`),lookbehind:!0,inside:{"attr-name":/^[^\s=]+/,"attr-value":{pattern:/=[\s\S]+/,inside:{value:{pattern:/(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,lookbehind:!0,alias:[t,`language-`+t],inside:n.languages[t]},punctuation:[{pattern:/^=/,alias:`attr-equals`},/"|'/]}}}})}}),n.languages.html=n.languages.markup,n.languages.mathml=n.languages.markup,n.languages.svg=n.languages.markup,n.languages.xml=n.languages.extend(`markup`,{}),n.languages.ssml=n.languages.xml,n.languages.atom=n.languages.xml,n.languages.rss=n.languages.xml,(function(e){var t=/(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;e.languages.css={comment:/\/\*[\s\S]*?\*\//,atrule:{pattern:RegExp(`@[\\w-](?:[^;{\\s"']|\\s+(?!\\s)|`+t.source+`)*?(?:;|(?=\\s*\\{))`),inside:{rule:/^@[\w-]+/,"selector-function-argument":{pattern:/(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,lookbehind:!0,alias:`selector`},keyword:{pattern:/(^|[^\w-])(?:and|not|only|or)(?![\w-])/,lookbehind:!0}}},url:{pattern:RegExp(`\\burl\\((?:`+t.source+`|(?:[^\\\\\\r\\n()"']|\\\\[\\s\\S])*)\\)`,`i`),greedy:!0,inside:{function:/^url/i,punctuation:/^\(|\)$/,string:{pattern:RegExp(`^`+t.source+`$`),alias:`url`}}},selector:{pattern:RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|`+t.source+`)*(?=\\s*\\{)`),lookbehind:!0},string:{pattern:t,greedy:!0},property:{pattern:/(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,lookbehind:!0},important:/!important\b/i,function:{pattern:/(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,lookbehind:!0},punctuation:/[(){};:,]/},e.languages.css.atrule.inside.rest=e.languages.css;var n=e.languages.markup;n&&(n.tag.addInlined(`style`,`css`),n.tag.addAttribute(`style`,`css`))})(n),n.languages.clike={comment:[{pattern:/(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,lookbehind:!0,greedy:!0},{pattern:/(^|[^\\:])\/\/.*/,lookbehind:!0,greedy:!0}],string:{pattern:/(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,greedy:!0},"class-name":{pattern:/(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,lookbehind:!0,inside:{punctuation:/[.\\]/}},keyword:/\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,boolean:/\b(?:false|true)\b/,function:/\b\w+(?=\()/,number:/\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,operator:/[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,punctuation:/[{}[\];(),.:]/},n.languages.javascript=n.languages.extend(`clike`,{"class-name":[n.languages.clike[`class-name`],{pattern:/(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,lookbehind:!0}],keyword:[{pattern:/((?:^|\})\s*)catch\b/,lookbehind:!0},{pattern:/(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,lookbehind:!0}],function:/#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,number:{pattern:RegExp(`(^|[^\\w$])(?:NaN|Infinity|0[bB][01]+(?:_[01]+)*n?|0[oO][0-7]+(?:_[0-7]+)*n?|0[xX][\\dA-Fa-f]+(?:_[\\dA-Fa-f]+)*n?|\\d+(?:_\\d+)*n|(?:\\d+(?:_\\d+)*(?:\\.(?:\\d+(?:_\\d+)*)?)?|\\.\\d+(?:_\\d+)*)(?:[Ee][+-]?\\d+(?:_\\d+)*)?)(?![\\w$])`),lookbehind:!0},operator:/--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/}),n.languages.javascript[`class-name`][0].pattern=/(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/,n.languages.insertBefore(`javascript`,`keyword`,{regex:{pattern:RegExp(`((?:^|[^$\\w\\xA0-\\uFFFF."'\\])\\s]|\\b(?:return|yield))\\s*)\\/(?:(?:\\[(?:[^\\]\\\\\\r\\n]|\\\\.)*\\]|\\\\.|[^/\\\\\\[\\r\\n])+\\/[dgimyus]{0,7}|(?:\\[(?:[^[\\]\\\\\\r\\n]|\\\\.|\\[(?:[^[\\]\\\\\\r\\n]|\\\\.|\\[(?:[^[\\]\\\\\\r\\n]|\\\\.)*\\])*\\])*\\]|\\\\.|[^/\\\\\\[\\r\\n])+\\/[dgimyus]{0,7}v[dgimyus]{0,7})(?=(?:\\s|\\/\\*(?:[^*]|\\*(?!\\/))*\\*\\/)*(?:$|[\\r\\n,.;:})\\]]|\\/\\/))`),lookbehind:!0,greedy:!0,inside:{"regex-source":{pattern:/^(\/)[\s\S]+(?=\/[a-z]*$)/,lookbehind:!0,alias:`language-regex`,inside:n.languages.regex},"regex-delimiter":/^\/|\/$/,"regex-flags":/^[a-z]+$/}},"function-variable":{pattern:/#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,alias:`function`},parameter:[{pattern:/(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,lookbehind:!0,inside:n.languages.javascript},{pattern:/(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,lookbehind:!0,inside:n.languages.javascript},{pattern:/(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,lookbehind:!0,inside:n.languages.javascript},{pattern:/((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,lookbehind:!0,inside:n.languages.javascript}],constant:/\b[A-Z](?:[A-Z_]|\dx?)*\b/}),n.languages.insertBefore(`javascript`,`string`,{hashbang:{pattern:/^#!.*/,greedy:!0,alias:`comment`},"template-string":{pattern:/`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,greedy:!0,inside:{"template-punctuation":{pattern:/^`|`$/,alias:`string`},interpolation:{pattern:/((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,lookbehind:!0,inside:{"interpolation-punctuation":{pattern:/^\$\{|\}$/,alias:`punctuation`},rest:n.languages.javascript}},string:/[\s\S]+/}},"string-property":{pattern:/((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,lookbehind:!0,greedy:!0,alias:`property`}}),n.languages.insertBefore(`javascript`,`operator`,{"literal-property":{pattern:/((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,lookbehind:!0,alias:`property`}}),n.languages.markup&&(n.languages.markup.tag.addInlined(`script`,`javascript`),n.languages.markup.tag.addAttribute(`on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)`,`javascript`)),n.languages.js=n.languages.javascript,(function(){if(n===void 0||typeof document>`u`)return;Element.prototype.matches||(Element.prototype.matches=Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector);var e=`Loading…`,t=function(e,t){return`✖ Error `+e+` while fetching file: `+t},r=`✖ Error: File does not exist or is empty`,i={js:`javascript`,py:`python`,rb:`ruby`,ps1:`powershell`,psm1:`powershell`,sh:`bash`,bat:`batch`,h:`c`,tex:`latex`},a=`data-src-status`,o=`loading`,s=`loaded`,c=`failed`,l=`pre[data-src]:not([`+a+`="`+s+`"]):not([`+a+`="`+o+`"])`;function u(e,n,i){var a=new XMLHttpRequest;a.open(`GET`,e,!0),a.onreadystatechange=function(){a.readyState==4&&(a.status<400&&a.responseText?n(a.responseText):a.status>=400?i(t(a.status,a.statusText)):i(r))},a.send(null)}function d(e){var t=/^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(e||``);if(t){var n=Number(t[1]),r=t[2],i=t[3];return r?i?[n,Number(i)]:[n,void 0]:[n,n]}}n.hooks.add(`before-highlightall`,function(e){e.selector+=`, `+l}),n.hooks.add(`before-sanity-check`,function(t){var r=t.element;if(r.matches(l)){t.code=``,r.setAttribute(a,o);var f=r.appendChild(document.createElement(`CODE`));f.textContent=e;var p=r.getAttribute(`data-src`),m=t.language;if(m===`none`){var h=(/\.(\w+)$/.exec(p)||[,`none`])[1];m=i[h]||h}n.util.setLanguage(f,m),n.util.setLanguage(r,m);var g=n.plugins.autoloader;g&&g.loadLanguages(m),u(p,function(e){r.setAttribute(a,s);var t=d(r.getAttribute(`data-range`));if(t){var i=e.split(/\r\n?|\n/g),o=t[0],c=t[1]==null?i.length:t[1];o<0&&(o+=i.length),o=Math.max(0,Math.min(o-1,i.length)),c<0&&(c+=i.length),c=Math.max(0,Math.min(c,i.length)),e=i.slice(o,c).join(`
`),r.hasAttribute(`data-start`)||r.setAttribute(`data-start`,String(o+1))}f.textContent=e,n.highlightElement(f)},function(e){r.setAttribute(a,c),f.textContent=e})}}),n.plugins.fileHighlight={highlight:function(e){for(var t=(e||document).querySelectorAll(l),r=0,i;i=t[r++];)n.highlightElement(i)}};var f=!1;n.fileHighlight=function(){f||=(console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."),!0),n.plugins.fileHighlight.highlight.apply(this,arguments)}})()}))(),1);Prism.languages.c=Prism.languages.extend(`clike`,{comment:{pattern:/\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,greedy:!0},string:{pattern:/"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,greedy:!0},"class-name":{pattern:/(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,lookbehind:!0},keyword:/\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,function:/\b[a-z_]\w*(?=\s*\()/i,number:/(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,operator:/>>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/}),Prism.languages.insertBefore(`c`,`string`,{char:{pattern:/'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,greedy:!0}}),Prism.languages.insertBefore(`c`,`string`,{macro:{pattern:/(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,lookbehind:!0,greedy:!0,alias:`property`,inside:{string:[{pattern:/^(#\s*include\s*)<[^>]+>/,lookbehind:!0},Prism.languages.c.string],char:Prism.languages.c.char,comment:Prism.languages.c.comment,"macro-name":[{pattern:/(^#\s*define\s+)\w+\b(?!\()/i,lookbehind:!0},{pattern:/(^#\s*define\s+)\w+\b(?=\()/i,lookbehind:!0,alias:`function`}],directive:{pattern:/^(#\s*)[a-z]+/,lookbehind:!0,alias:`keyword`},"directive-hash":/^#/,punctuation:/##|\\(?=[\r\n])/,expression:{pattern:/\S[\s\S]*/,inside:Prism.languages.c}}}}),Prism.languages.insertBefore(`c`,`function`,{constant:/\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/}),delete Prism.languages.c.boolean,(function(e){var t=/\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/,n=`\\b(?!<keyword>)\\w+(?:\\s*\\.\\s*\\w+)*\\b`.replace(/<keyword>/g,function(){return t.source});e.languages.cpp=e.languages.extend(`c`,{"class-name":[{pattern:RegExp(`(\\b(?:class|concept|enum|struct|typename)\\s+)(?!<keyword>)\\w+`.replace(/<keyword>/g,function(){return t.source})),lookbehind:!0},/\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,/\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,/\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/],keyword:t,number:{pattern:/(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,greedy:!0},operator:/>>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,boolean:/\b(?:false|true)\b/}),e.languages.insertBefore(`cpp`,`string`,{module:{pattern:RegExp(`(\\b(?:import|module)\\s+)(?:"(?:\\\\(?:\\r\\n|[\\s\\S])|[^"\\\\\\r\\n])*"|<[^<>\\r\\n]*>|`+`<mod-name>(?:\\s*:\\s*<mod-name>)?|:\\s*<mod-name>`.replace(/<mod-name>/g,function(){return n})+`)`),lookbehind:!0,greedy:!0,inside:{string:/^[<"][\s\S]+/,operator:/:/,punctuation:/\./}},"raw-string":{pattern:/R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,alias:`string`,greedy:!0}}),e.languages.insertBefore(`cpp`,`keyword`,{"generic-function":{pattern:/\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,inside:{function:/^\w+/,generic:{pattern:/<[\s\S]+/,alias:`class-name`,inside:e.languages.cpp}}}}),e.languages.insertBefore(`cpp`,`operator`,{"double-colon":{pattern:/::/,alias:`punctuation`}}),e.languages.insertBefore(`cpp`,`class-name`,{"base-clause":{pattern:/(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,lookbehind:!0,greedy:!0,inside:e.languages.extend(`cpp`,{})}}),e.languages.insertBefore(`inside`,`double-colon`,{"class-name":/\b[a-z_]\w*\b(?!\s*::)/i},e.languages.cpp[`base-clause`])})(Prism),(function(e){var t=/\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/,n=`(?:[a-z]\\w*\\s*\\.\\s*)*(?:[A-Z]\\w*\\s*\\.\\s*)*`,r={pattern:RegExp(`(^|[^\\w.])`+n+`[A-Z](?:[\\d_A-Z]*[a-z]\\w*)?\\b`),lookbehind:!0,inside:{namespace:{pattern:/^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,inside:{punctuation:/\./}},punctuation:/\./}};e.languages.java=e.languages.extend(`clike`,{string:{pattern:/(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,lookbehind:!0,greedy:!0},"class-name":[r,{pattern:RegExp(`(^|[^\\w.])`+n+`[A-Z]\\w*(?=\\s+\\w+\\s*[;,=()]|\\s*(?:\\[[\\s,]*\\]\\s*)?::\\s*new\\b)`),lookbehind:!0,inside:r.inside},{pattern:RegExp(`(\\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\\s+)`+n+`[A-Z]\\w*\\b`),lookbehind:!0,inside:r.inside}],keyword:t,function:[e.languages.clike.function,{pattern:/(::\s*)[a-z_]\w*/,lookbehind:!0}],number:/\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,operator:{pattern:/(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,lookbehind:!0},constant:/\b[A-Z][A-Z_\d]+\b/}),e.languages.insertBefore(`java`,`string`,{"triple-quoted-string":{pattern:/"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,greedy:!0,alias:`string`},char:{pattern:/'(?:\\.|[^'\\\r\n]){1,6}'/,greedy:!0}}),e.languages.insertBefore(`java`,`class-name`,{annotation:{pattern:/(^|[^.])@\w+(?:\s*\.\s*\w+)*/,lookbehind:!0,alias:`punctuation`},generics:{pattern:/<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,inside:{"class-name":r,keyword:t,punctuation:/[<>(),.:]/,operator:/[?&|]/}},import:[{pattern:RegExp(`(\\bimport\\s+)`+n+`(?:[A-Z]\\w*|\\*)(?=\\s*;)`),lookbehind:!0,inside:{namespace:r.inside.namespace,punctuation:/\./,operator:/\*/,"class-name":/\w+/}},{pattern:RegExp(`(\\bimport\\s+static\\s+)`+n+`(?:\\w+|\\*)(?=\\s*;)`),lookbehind:!0,alias:`static`,inside:{namespace:r.inside.namespace,static:/\b\w+$/,punctuation:/\./,operator:/\*/,"class-name":/\w+/}}],namespace:{pattern:RegExp(`(\\b(?:exports|import(?:\\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\\s+)(?!<keyword>)[a-z]\\w*(?:\\.[a-z]\\w*)*\\.?`.replace(/<keyword>/g,function(){return t.source})),lookbehind:!0,inside:{punctuation:/\./}}})})(Prism),Prism.languages.python={comment:{pattern:/(^|[^\\])#.*/,lookbehind:!0,greedy:!0},"string-interpolation":{pattern:/(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,greedy:!0,inside:{interpolation:{pattern:/((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,lookbehind:!0,inside:{"format-spec":{pattern:/(:)[^:(){}]+(?=\}$)/,lookbehind:!0},"conversion-option":{pattern:/![sra](?=[:}]$)/,alias:`punctuation`},rest:null}},string:/[\s\S]+/}},"triple-quoted-string":{pattern:/(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,greedy:!0,alias:`string`},string:{pattern:/(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,greedy:!0},function:{pattern:/((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,lookbehind:!0},"class-name":{pattern:/(\bclass\s+)\w+/i,lookbehind:!0},decorator:{pattern:/(^[\t ]*)@\w+(?:\.\w+)*/m,lookbehind:!0,alias:[`annotation`,`punctuation`],inside:{punctuation:/\./}},keyword:/\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,builtin:/\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,boolean:/\b(?:False|None|True)\b/,number:/\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,operator:/[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,punctuation:/[{}[\];(),.:]/},Prism.languages.python[`string-interpolation`].inside.interpolation.inside.rest=Prism.languages.python,Prism.languages.py=Prism.languages.python;function l(e){let t=document.createElement(`div`);t.id=`pta-confirm-dialog`,t.style.position=`fixed`,t.style.top=`0`,t.style.left=`0`,t.style.width=`100%`,t.style.height=`100%`,t.style.background=`rgba(0, 0, 0, 0.5)`,t.style.display=`flex`,t.style.justifyContent=`center`,t.style.alignItems=`center`,t.style.zIndex=`999999`,t.style.backdropFilter=`blur(2px)`;let n=document.createElement(`div`);n.style.background=`white`,n.style.borderRadius=`6px`,n.style.boxShadow=`0 4px 20px rgba(0, 0, 0, 0.15)`,n.style.width=`400px`,n.style.maxWidth=`90%`,n.style.overflow=`hidden`;let r=document.createElement(`div`);r.style.padding=`16px`,r.style.borderBottom=`1px solid #e0e0e0`,r.style.display=`flex`,r.style.justifyContent=`space-between`,r.style.alignItems=`center`;let i=document.createElement(`div`);i.style.fontSize=`16px`,i.style.fontWeight=`bold`,i.style.color=`#333`,i.textContent=e.header||`确认`;let a=document.createElement(`button`);a.style.background=`none`,a.style.border=`none`,a.style.fontSize=`20px`,a.style.cursor=`pointer`,a.style.color=`#666`,a.textContent=`×`,a.addEventListener(`click`,()=>{e.reject&&e.reject(),document.body.removeChild(t)}),r.appendChild(i),r.appendChild(a);let o=document.createElement(`div`);o.style.padding=`20px`;let s=document.createElement(`div`);s.style.fontSize=`14px`,s.style.color=`#333`,s.style.lineHeight=`1.5`,s.textContent=e.message,o.appendChild(s);let c=document.createElement(`div`);c.style.padding=`16px`,c.style.borderTop=`1px solid #e0e0e0`,c.style.display=`flex`,c.style.justifyContent=`flex-end`,c.style.gap=`10px`;let l=document.createElement(`button`);l.style.padding=`8px 16px`,l.style.border=`1px solid #ddd`,l.style.borderRadius=`4px`,l.style.background=`white`,l.style.color=`#333`,l.style.cursor=`pointer`,l.style.fontSize=`14px`,l.textContent=`取消`,l.addEventListener(`click`,()=>{e.reject&&e.reject(),document.body.removeChild(t)});let u=document.createElement(`button`);u.style.padding=`8px 16px`,u.style.border=`none`,u.style.borderRadius=`4px`,u.style.background=`#4CAF50`,u.style.color=`white`,u.style.cursor=`pointer`,u.style.fontSize=`14px`,u.textContent=`确认`,u.addEventListener(`click`,()=>{document.body.removeChild(t),e.accept&&e.accept()}),c.appendChild(l),c.appendChild(u),n.appendChild(r),n.appendChild(o),n.appendChild(c),t.appendChild(n),document.body.appendChild(t),t.addEventListener(`click`,n=>{n.target===t&&(e.reject&&e.reject(),document.body.removeChild(t))})}function u(e,t=`info`){let n=document.getElementById(`pta-toast-container`);n||(n=document.createElement(`div`),n.id=`pta-toast-container`,n.style.position=`fixed`,n.style.top=`20px`,n.style.right=`20px`,n.style.zIndex=`999999`,n.style.display=`flex`,n.style.flexDirection=`column`,n.style.gap=`10px`,document.body.appendChild(n));let r=document.createElement(`div`);switch(r.style.padding=`12px 16px`,r.style.borderRadius=`4px`,r.style.color=`white`,r.style.fontSize=`14px`,r.style.fontWeight=`500`,r.style.boxShadow=`0 4px 12px rgba(0,0,0,0.15)`,r.style.transition=`all 0.3s ease`,r.style.opacity=`0`,r.style.transform=`translateX(100%)`,t){case`success`:r.style.backgroundColor=`#4CAF50`;break;case`error`:r.style.backgroundColor=`#f44336`;break;case`warning`:r.style.backgroundColor=`#ff9800`;break;default:r.style.backgroundColor=`#2196F3`}r.textContent=e,n.appendChild(r),setTimeout(()=>{r.style.opacity=`1`,r.style.transform=`translateX(0)`},10),setTimeout(()=>{r.style.opacity=`0`,r.style.transform=`translateX(100%)`,setTimeout(()=>{r.parentNode&&r.parentNode.removeChild(r)},300)},3e3)}function d(e,t=null){_(function(n){n.debugMode&&n.debugEnabled&&console.log(`[PTA 答题辅助] `+e,t)})}var f={autoPopup:!0,language:`c`,aiEnabled:!1,aiApiKey:``,aiApiUrl:`https://api.openai.com/v1`,aiModel:`gpt-3.5-turbo`,debugMode:!1,debugEnabled:!1,showBuildTime:!1,extractDelay:2e3,modelSelectMode:`random`,selectedModelId:``,apiSources:[],aiSystemPrompt:`你是专业的编程题 AC 生成器。
语言：{language}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。

以下是题目内容：
{problem content}`,aiErrorPrompt:`你是专业的编程题 AC 生成器。
语言：{language}
错误类型：{error_type}
编译器提示：{compiler_msg}
测试点提示提示：{data_tip}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。
题目如下：
{problem content}
错误源码如下：
{res_code}`,choiceBatchSize:20,choicePrompt:`你是一个专业的AI做题工具
请直接输出**符合格式的JSON**，不要解释、不要说明、不要多余内容。

格式如下
[
  "A",
  "B"
]

以下是题目内容：
{problem content}`};function p(e){let t=[];return Array.isArray(e)&&e.forEach(e=>{e.enabled&&e.models.forEach(n=>{t.push({id:n,sourceName:e.name,sourceUrl:e.url,sourceKeys:e.keys})})}),t}function m(e){if(e.aiApiKey)return{url:e.aiApiUrl||`https://api.openai.com/v1`,key:e.aiApiKey,model:e.aiModel||`gpt-3.5-turbo`};let t=Array.isArray(e.apiSources)?e.apiSources:[],n=t.filter(e=>e.enabled);if(n.length===0)return null;let r=p(t);if(r.length===0)return null;let i,a;return e.modelSelectMode===`manual`&&e.selectedModelId?(i=r.find(t=>t.id===e.selectedModelId),i||=r[Math.floor(Math.random()*r.length)]):i=r[Math.floor(Math.random()*r.length)],a=n.find(e=>e.models.includes(i.id)),!a||!i?null:{url:a.url,key:a.keys[Math.floor(Math.random()*a.keys.length)],model:i.id}}var h=``;window.currentSubmissionData=null;var g=[];function _(e){try{chrome.storage.local.get(Object.keys(f),function(t){try{let n={...f,...t},r=!1;for(let e in f)if(!(e in t)){r=!0;break}r&&chrome.storage.local.set(n,function(){console.log(`配置已更新为默认值`)}),e(n)}catch(t){console.warn(`处理配置时出错:`,t),e(f)}})}catch(t){console.warn(`获取配置时出错:`,t),e(f)}}function v(){_(function(e){if(e.autoPopup){let e=S(),t=x(),n=w(),r=T();n?(W(),L(),setTimeout(()=>{D()},100)):e?(W(),L(),setTimeout(()=>{E()},100)):t?(W(),L(),setTimeout(()=>{y()},100)):r?b():W()}else W()})}function y(){setTimeout(async()=>{await O()},10)}function b(){setTimeout(async()=>{await re()},10)}function x(){let e=window.location.href;return/\/problem-sets\/.+\/exam\/problems\/type\/[67]/.test(e)&&/problemSetProblemId=\d+/.test(e)}function S(){let e=window.location.href;return/\/problem-sets\/.+\/exam\/problems\/type\/[67]$/.test(e)}function C(){let e=window.location.href;return/\/type\/7/.test(e)?`PROGRAMMING`:/\/type\/6/.test(e)?`CODE_COMPLETION`:`PROGRAMMING`}function w(){let e=window.location.href;return/\/problem-sets\/.+\/exam\/problems\/type\/2/.test(e)}function T(){let e=window.location.href;return e.includes(`/problem-sets/`)&&e.includes(`/exam/submissions/`)}async function E(){if(!S())return;let e=document.getElementById(`pta-problem-list`),t=document.getElementById(`pta-problem-list-status`);if(e)try{let n=window.location.href.match(/\/problem-sets\/(\d+)/);if(!n){u(`无法从URL中提取problemSetId`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取题目列表</span></div>`;return}let r=n[1],i=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!i.ok){u(`获取examId失败: ${i.status}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取examId</span></div>`;return}let a=(await i.json()).exam?.id;if(!a){u(`无法获取examId`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取examId</span></div>`;return}let o=C(),s=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problem-list?exam_id=${a}&problem_type=${o}&page=0&limit=100`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!s.ok){u(`获取题目列表失败: ${s.status}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">获取题目列表失败</span></div>`;return}let c=await s.json(),d=c.examLabelByProblemSetProblemId||{};if(c.problemSetProblems){let n=``;c.problemSetProblems.forEach((e,t)=>{let r=d[e.id]||`${t+1}`;n+=`<div class="problem-item" data-id="${e.id}">
          <span class="problem-index">${r}</span>
          <span class="problem-title">${e.title}</span>
          <button class="problem-action-btn">一键完成</button>
        </div>`}),e.innerHTML=n,t&&(t.textContent=`共 ${c.problemSetProblems.length} 道题目`,t.className=`success`),e.querySelectorAll(`.problem-item`).forEach(e=>{e.addEventListener(`click`,function(e){if(e.target.classList.contains(`problem-action-btn`))return;let t=this.getAttribute(`data-id`);this.querySelector(`.problem-title`).textContent;let n=C()===`CODE_COMPLETION`?`6`:`7`;window.open(`https://pintia.cn/problem-sets/${r}/exam/problems/type/${n}?problemSetProblemId=${t}`,`_blank`)});let t=e.querySelector(`.problem-action-btn`);t&&t.addEventListener(`click`,async function(){let n=e.getAttribute(`data-id`);e.querySelector(`.problem-title`).textContent,t.disabled=!0;try{t.textContent=`读题`,t.style.background=`#2196F3`;let e=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!e.ok)throw Error(`获取examId失败`);if(!(await e.json()).exam?.id)throw Error(`无法获取examId`);let i=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problems/${n}`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!i.ok)throw Error(`获取题目内容失败`);let a=await i.json(),o=``;if(a&&a.problemSetProblem&&(o=a.problemSetProblem.content||a.problemSetProblem.description||``),!o)throw Error(`未提取到题目内容`);t.textContent=`AI生成`,t.style.background=`#ff9800`;let s=await new Promise(e=>{_(e)}),c=m(s);if(!s.aiEnabled||!c)throw Error(`AI 未启用或未配置 API 密钥`);let l=c.key,u=c.url,d=c.model,f=s.aiSystemPrompt,p=s.language;f=f.replace(`{language}`,p).replace(`{problem content}`,o);let h=await I(u,l,d,[{role:`system`,content:f},{role:`user`,content:``}]);if(!h)throw Error(`AI 未返回有效结果`);h=h.replace(/```[\w]*\n?/g,``).trim();let g=await q(h,r,n);if(!g.success)throw Error(`提交失败: `+g.error);g.examId&&g.submissionId?Y(t,g.examId,g.submissionId):(t.textContent=`完成`,t.style.background=`#2196F3`,t.disabled=!1)}catch(e){u(`一键完成出现错误: ${e.message}`,`error`),t&&t.parentNode&&(t.textContent=`失败`,t.style.background=`#f44336`,setTimeout(()=>{t&&t.parentNode&&(t.textContent=`一键完成`,t.style.background=`#4CAF50`,t.disabled=!1)},2e3))}})});let i=document.getElementById(`pta-complete-all-btn`),a=document.getElementById(`pta-complete-all-status`);i&&i.addEventListener(`click`,async function(){l({message:`确定要一键完成所有题目吗？这将自动处理当前列表中的所有题目。`,header:`确认操作`,icon:`pi pi-exclamation-triangle`,accept:async()=>{i.disabled=!0,i.textContent=`处理中...`,a.style.display=`block`,a.className=`processing`,a.textContent=`正在处理题目...`;try{let t=c.problemSetProblems,n=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!n.ok)throw Error(`获取examId失败`);if(!(await n.json()).exam?.id)throw Error(`无法获取examId`);let o=await new Promise(e=>{_(e)}),s=m(o);if(!o.aiEnabled||!s)throw Error(`AI 未启用或未配置 API 密钥`);let l={AC:0,WA:0,PA:0,CE:0,SF:0,ERROR:0,PENDING:t.length,SUBMITTED:0,TIMEOUT:0};function d(e,t){if(t===`SUBMITTED`||t===`TIMEOUT`)l[t]=(l[t]||0)+1;else{let e=t===`ACCEPTED`?`AC`:t===`PARTIAL_ACCEPTED`?`PA`:t===`WRONG_ANSWER`?`WA`:t===`COMPILE_ERROR`?`CE`:t===`SEGMENTATION_FAULT`?`SF`:t===`ERROR`?`ERROR`:t;l[e]=(l[e]||0)+1}l.PENDING=Math.max(0,l.PENDING-1);let n=[];l.AC>0&&n.push(`✅${l.AC}`),l.WA>0&&n.push(`❌${l.WA}`),l.PA>0&&n.push(`⚠️${l.PA}`),l.CE>0&&n.push(`🔧${l.CE}`),l.SF>0&&n.push(`💥${l.SF}`),l.ERROR>0&&n.push(`🚫${l.ERROR}`),l.TIMEOUT>0&&n.push(`⏰${l.TIMEOUT}`),l.PENDING>0&&n.push(`⏳${l.PENDING}`),l.PENDING===0&&(e.className=`success`),e.textContent=n.join(` `)||`处理完成`}let f=[],p=async(t,n)=>{let i=t.id,c=t.title,l=e.querySelector(`.problem-item[data-id="${i}"]`),f=l?l.querySelector(`.problem-action-btn`):null;try{f&&(f.textContent=`读题`,f.style.background=`#2196F3`,f.disabled=!0);let e=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problems/${i}`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!e.ok)throw Error(`获取题目内容失败`);let t=await e.json(),n=``;if(t&&t.problemSetProblem&&(n=t.problemSetProblem.content||t.problemSetProblem.description||``),!n)throw Error(`未提取到题目内容`);f&&(f.textContent=`AI生成`,f.style.background=`#ff9800`);let c=s.key,l=s.url,u=s.model,p=o.aiSystemPrompt,m=o.language;p=p.replace(`{language}`,m).replace(`{problem content}`,n);let h=await I(l,c,u,[{role:`system`,content:p},{role:`user`,content:``}]);if(!h)throw Error(`AI 未返回有效结果`);h=h.replace(/```[\w]*\n?/g,``).trim();let g=await q(h,r,i);if(!g.success)throw Error(`提交失败: `+g.error);let _=`SUBMITTED`;return f&&(g.examId&&g.submissionId?_=await Y(f,g.examId,g.submissionId):(f.textContent=`完成`,f.style.background=`#2196F3`,f.disabled=!1)),d(a,_),_}catch(e){return u(`处理题目 ${c} 失败: ${e.message}`,`error`),f&&(f.textContent=`失败`,f.style.background=`#f44336`,setTimeout(()=>{f.textContent=`一键完成`,f.style.background=`#4CAF50`,f.disabled=!1},2e3)),d(a,`ERROR`),`ERROR`}};for(let e=0;e<t.length;e++){let n=new Promise(t=>{setTimeout(t,e*500)}).then(()=>p(t[e],e));f.push(n)}await Promise.all(f),i.textContent=`完成所有题目`,i.disabled=!1}catch(e){u(`一键完成所有题目失败: ${e.message}`,`error`),a.className=`error`,a.textContent=`处理失败: `+e.message,i.textContent=`一键完成所有题目`,i.disabled=!1}},reject:()=>{}})})}}catch(n){u(`获取题目列表出错: ${n.message}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">获取题目列表出错</span></div>`,t&&(t.textContent=`获取题目列表出错`,t.className=`error`)}}async function D(){if(w())try{let e=window.location.href.match(/\/problem-sets\/(\d+)/);if(!e){console.log(`无法从URL中提取problemSetId`);return}let t=e[1],n=await fetch(`https://pintia.cn/api/problem-sets/${t}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!n.ok){console.log(`获取examId失败:`,n.status);return}let r=(await n.json()).exam?.id;if(!r){console.log(`无法获取examId`);return}window.choiceExamId=r,window.choiceProblemSetId=t;let i=await fetch(`https://pintia.cn/api/problem-sets/${t}/exam-problems?exam_id=${r}&problem_type=MULTIPLE_CHOICE`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!i.ok){console.log(`获取选择题列表失败:`,i.status);return}let a=await i.json();if(a.problemSetProblems){let e=a.problemSetProblems.map(e=>({id:e.id,content:e.content||e.description||``,choices:e.problemConfig?.multipleChoiceProblemConfig?.choices||[]}));window.choiceQuestions=e,console.log(`选择题列表（精简）:`,e);let t=document.getElementById(`pta-choice-count`);t&&(t.textContent=`共 ${e.length} 题`);let n=document.getElementById(`pta-choice-batch-btn`);n&&(n.disabled=!1);let r=document.getElementById(`pta-helper-float`);r&&z(r)}else console.log(`选择题列表响应:`,a)}catch(e){console.error(`获取选择题列表出错:`,e)}}async function O(){if(!x())return null;try{let e=window.location.href,t=e.match(/\/problem-sets\/(\d+)/),n=e.match(/problemSetProblemId=(\d+)/);if(!t||!n)return u(`无法从URL中提取问题集ID或问题ID`,`error`),null;let r=`https://pintia.cn/api/problem-sets/${t[1]}/exam-problems/${n[1]}`,i=await fetch(r,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,priority:`u=1, i`,"sec-ch-ua":`"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"`,"sec-ch-ua-mobile":`?0`,"sec-ch-ua-platform":`"Windows"`,"sec-fetch-dest":`empty`,"sec-fetch-mode":`cors`,"sec-fetch-site":`same-origin`,"x-lollipop":K(),"x-marshmallow":``},referrer:e,body:null,method:`GET`,mode:`cors`,credentials:`include`});if(!i.ok)return u(`API请求失败: ${i.status} ${i.statusText}`,`error`),null;let a=await i.json(),o=``;return a&&a.problemSetProblem&&(a.problemSetProblem.content?o=a.problemSetProblem.content:a.problemSetProblem.description&&(o=a.problemSetProblem.description)),h=o,g=[],k(h),a}catch(e){return u(`获取题目数据时出错: ${e.message}`,`error`),null}}async function k(e,t=!1,n=``,r=0){_(async function(i){if(!i.aiEnabled)return;let a=m(i);if(!a){u(`未配置 API 密钥`,`warning`);return}let o=a.key,s=a.url,l=a.model,f=i.aiSystemPrompt,p=i.language;f=f.replace(`{language}`,p).replace(`{problem content}`,e);let h=[{role:`system`,content:f}];d(`发给 AI 的内容`,h),g.length>0&&(h=h.concat(g));let _=``;_=t&&n?`之前的代码有误，错误信息：${n}\n\n请重新思考并修正代码。`:t?`之前的代码有误，请重新思考并修正代码。`:``,h.push({role:`user`,content:_});try{let i=``,a=document.getElementById(`pta-code-input`),f=document.getElementById(`pta-code-highlight`);await F(s,o,l,h,e=>{if(i+=e,a&&f){let e=i.replace(/```[\w]*\n?/g,``).trim();a.value=e,f.innerHTML=A(e),c.default.highlightElement(f)}},()=>{d(`AI 返回的内容`,i),g.push({role:`user`,content:_}),g.push({role:`assistant`,content:i})},async i=>{u(`AI 调用出错：${i.message}`,`error`),r<3?(u(`尝试使用其他模型...`,`info`),g=[],setTimeout(()=>{k(e,t,n,r+1)},1e3)):u(`所有模型均失败，请检查 API 配置`,`error`)})}catch(i){u(`AI 调用出错：${i.message}`,`error`),r<3?(u(`尝试使用其他模型...`,`info`),g=[],setTimeout(()=>{k(e,t,n,r+1)},1e3)):u(`所有模型均失败，请检查 API 配置`,`error`)}})}function A(e){let t=document.createElement(`div`);return t.textContent=e,t.innerHTML}typeof global>`u`&&(window.global=window);function j(){let e=document.createElement(`div`);e.style.position=`fixed`,e.style.top=`20px`,e.style.right=`20px`,e.style.padding=`12px 16px`,e.style.borderRadius=`8px`,e.style.backgroundColor=`#ff4d4f`,e.style.color=`#fff`,e.style.fontSize=`14px`,e.style.fontWeight=`500`,e.style.zIndex=`999999`,e.style.boxShadow=`0 4px 12px rgba(0, 0, 0, 0.15)`,e.style.cursor=`pointer`,e.style.transition=`all 0.3s ease`,e.style.opacity=`0`,e.style.transform=`translateY(-20px)`,e.textContent=`提交失败？点击查看使用PyCatch提交的方法`,e.addEventListener(`click`,()=>{console.log(`提示框被点击`),chrome.runtime.sendMessage({action:`openOptionsWithTab`,tab:`subErr`},e=>{console.log(`消息发送结果`,e)})}),document.body.appendChild(e),setTimeout(()=>{e.style.opacity=`1`,e.style.transform=`translateY(0)`},100),setTimeout(()=>{e.style.opacity=`0`,e.style.transform=`translateY(-20px)`,setTimeout(()=>{e.parentNode&&document.body.removeChild(e)},300)},1e4)}function M(e,t){let n=e.toLowerCase(),r=t.toLowerCase();return n.includes(`siliconflow`)||n.includes(`silicon-flow`)||n.includes(`api.siliconflow.cn`)||r.includes(`siliconflow`)?`siliconflow`:n.includes(`volcano`)||n.includes(`ark.cn-beijing.volces.com`)||n.includes(`volces.com`)||r.includes(`volcano`)?`volcano`:n.includes(`aliyun`)||n.includes(`bailian`)||n.includes(`dashscope`)||r.includes(`bailian`)?`aliyun`:n.includes(`anthropic`)||n.includes(`claude`)||r.includes(`claude`)?`anthropic`:n.includes(`google`)||n.includes(`gemini`)||r.includes(`gemini`)?`google`:n.includes(`azure`)||n.includes(`openai.azure`)?`azure`:n.includes(`deepseek`)||r.includes(`deepseek`)?`deepseek`:n.includes(`openai`)||r.includes(`gpt`)?`openai`:`openai-compatible`}var N={name:`OpenAI`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] OpenAI流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] OpenAI非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},P={openai:N,anthropic:{name:`Anthropic`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] Anthropic流式调用`,{apiUrl:e,model:n});let o=r.find(e=>e.role===`system`)?.content||``,s=r.filter(e=>e.role!==`system`),c=await fetch(`${e}/v1/messages`,{method:`POST`,headers:{"Content-Type":`application/json`,"x-api-key":t,"anthropic-version":`2023-06-01`},body:JSON.stringify({model:n,max_tokens:4096,temperature:.7,system:o,messages:s.map(e=>({role:e.role===`assistant`?`assistant`:`user`,content:e.content})),stream:!0})});if(!c.ok){let e=await c.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${c.status}`)}let l=c.body.getReader(),u=new TextDecoder,d=``;for(;;){let{done:e,value:t}=await l.read();if(e)break;d+=u.decode(t,{stream:!0});let n=d.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t);e.type===`content_block_delta`&&e.delta?.text&&i(e.delta.text)}catch{}}d=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] Anthropic非流式调用`,{apiUrl:e,model:n});let i=r.find(e=>e.role===`system`)?.content||``,a=r.filter(e=>e.role!==`system`),o=await fetch(`${e}/v1/messages`,{method:`POST`,headers:{"Content-Type":`application/json`,"x-api-key":t,"anthropic-version":`2023-06-01`},body:JSON.stringify({model:n,max_tokens:4096,temperature:.7,system:i,messages:a.map(e=>({role:e.role===`assistant`?`assistant`:`user`,content:e.content}))})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}return(await o.json()).content?.[0]?.text||``}},google:{name:`Google`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] Google流式调用`,{apiUrl:e,model:n});let o=r.map(e=>({role:e.role===`user`?`user`:`model`,parts:[{text:e.content}]})),s=await fetch(`${e}/v1beta/models/${n}:streamGenerateContent?key=${t}`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:o,generationConfig:{temperature:.7,maxOutputTokens:4096}})});if(!s.ok){let e=await s.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${s.status}`)}let c=s.body.getReader(),l=new TextDecoder;for(;;){let{done:e,value:t}=await c.read();if(e)break;let n=l.decode(t);try{let e=n.split(`
`).filter(e=>e.trim());for(let t of e){let e=JSON.parse(t).candidates?.[0]?.content?.parts?.[0]?.text;e&&i(e)}}catch{}}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] Google非流式调用`,{apiUrl:e,model:n});let i=r.map(e=>({role:e.role===`user`?`user`:`model`,parts:[{text:e.content}]})),a=await fetch(`${e}/v1beta/models/${n}:generateContent?key=${t}`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:i,generationConfig:{temperature:.7,maxOutputTokens:4096}})});if(!a.ok){let e=await a.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${a.status}`)}return(await a.json()).candidates?.[0]?.content?.parts?.[0]?.text||``}},azure:{name:`Azure`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] Azure流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/openai/deployments/${n}/chat/completions?api-version=2024-02-01`,{method:`POST`,headers:{"Content-Type":`application/json`,"api-key":t},body:JSON.stringify({messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] Azure非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/openai/deployments/${n}/chat/completions?api-version=2024-02-01`,{method:`POST`,headers:{"Content-Type":`application/json`,"api-key":t},body:JSON.stringify({messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},deepseek:{name:`DeepSeek`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] DeepSeek流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] DeepSeek非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},siliconflow:{name:`SiliconFlow`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] 硅基流动流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] 硅基流动非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},volcano:{name:`Volcano`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] 火山方舟流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/api/v3/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] 火山方舟非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/api/v3/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},aliyun:{name:`Aliyun`,async stream(e,t,n,r,i,a,o){try{console.log(`[PTA AI] 阿里云百炼流式调用`,{apiUrl:e,model:n});let o=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!0})});if(!o.ok){let e=await o.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${o.status}`)}let s=o.body.getReader(),c=new TextDecoder,l=``;for(;;){let{done:e,value:t}=await s.read();if(e)break;l+=c.decode(t,{stream:!0});let n=l.split(`
`);for(let e of n)if(e.startsWith(`data: `)){let t=e.slice(6);if(t===`[DONE]`){a();return}try{let e=JSON.parse(t).choices?.[0]?.delta?.content;e&&i(e)}catch{}}l=n[n.length-1]}a()}catch(e){o(e)}},async generate(e,t,n,r){console.log(`[PTA AI] 阿里云百炼非流式调用`,{apiUrl:e,model:n});let i=await fetch(`${e}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify({model:n,messages:r,temperature:.7,stream:!1})});if(!i.ok){let e=await i.json().catch(()=>({message:`未知错误`}));throw Error(e.message||`HTTP ${i.status}`)}return(await i.json()).choices?.[0]?.message?.content||``}},"openai-compatible":N};async function F(e,t,n,r,i,a,o){let s=P[M(e,n)]||P[`openai-compatible`];console.log(`[PTA AI] 使用适配器`,{provider:s.name,apiUrl:e,model:n}),await s.stream(e,t,n,r,i,a,o)}async function I(e,t,n,r){let i=P[M(e,n)]||P[`openai-compatible`];return console.log(`[PTA AI] 使用适配器`,{provider:i.name,apiUrl:e,model:n}),await i.generate(e,t,n,r)}function L(){if(document.getElementById(`pta-helper-float`))return;let e=document.createElement(`div`);e.id=`pta-helper-float`,w()?e.innerHTML=V():S()?e.innerHTML=H():e.innerHTML=ee();let t=document.createElement(`style`);t.textContent=`
    #pta-helper-float {
      position: fixed;
      top: 50px;
      right: 20px;
      width: 500px;
      max-height: 80vh;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: Arial, sans-serif;
      overflow-y: auto;
    }
    .pta-float-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: #4CAF50;
      color: white;
      border-radius: 8px 8px 0 0;
      cursor: move;
      position: sticky;
      top: 0;
      z-index: 1;
    }
    .pta-float-header span {
      font-weight: bold;
      font-size: 16px;
    }
    .pta-float-close {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pta-float-close:hover {
      background: rgba(255,255,255,0.2);
      border-radius: 4px;
    }
    .pta-float-body {
      padding: 20px;
    }
    .code-editor-container {
      position: relative;
      width: 100%;
      height: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
      overflow: hidden;
    }
    .code-editor-container pre {
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      padding: 12px;
      width: 100%;
      height: 100%;
      background: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      overflow: auto;
      pointer-events: none;
      white-space: pre;
    }
    .code-editor-container code {
      font-family: 'Courier New', monospace;
    }
    #pta-code-input {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      padding: 12px;
      border: none;
      background: transparent;
      color: transparent;
      caret-color: #333;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      resize: none;
      box-sizing: border-box;
      z-index: 1;
      white-space: pre;
      overflow: auto;
    }
    #pta-code-input:focus {
      outline: none;
    }
    .pta-buttons {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }
    #pta-submit-btn, #pta-report-error-btn {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    #pta-submit-btn {
      background: #4CAF50;
      color: white;
    }
    #pta-submit-btn:hover {
      background: #45a049;
    }
    #pta-submit-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-report-error-btn {
      background: #ff9800;
      color: white;
    }
    #pta-report-error-btn:hover {
      background: #f57c00;
    }
    .error-section {
      margin-top: 15px;
      padding: 15px;
      background: #fff3e0;
      border-radius: 4px;
      border: 1px solid #ffcc80;
    }
    #pta-error-note {
      width: 100%;
      height: 80px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      resize: vertical;
      font-family: Arial, sans-serif;
      font-size: 13px;
      box-sizing: border-box;
    }
    .btn-retry {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      background: #f44336;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    .btn-retry:hover {
      background: #d32f2f;
    }
    #pta-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-status.error {
      color: #f44336;
      background: #ffebee;
    }
    .problem-list {
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .problem-item {
      display: flex;
      padding: 10px 12px;
      border-bottom: 1px solid #eee;
      cursor: pointer;
    }
    .problem-item:last-child {
      border-bottom: none;
    }
    .problem-item:hover {
      background: #f5f5f5;
    }
    .problem-index {
      font-weight: bold;
      color: #4CAF50;
      margin-right: 12px;
      min-width: 60px;
    }
    .problem-title {
      color: #333;
      flex: 1;
    }
    .problem-action-btn {
      background: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      white-space: nowrap;
    }
    .problem-action-btn:hover {
      background: #45a049;
    }
    .problem-action-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    .btn-complete-all {
      width: 100%;
      padding: 10px;
      background: #2196F3;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 15px;
    }
    .btn-complete-all:hover {
      background: #1976D2;
    }
    .btn-complete-all:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-problem-list-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-complete-all-status {
      margin-top: 10px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-complete-all-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-complete-all-status.error {
      color: #f44336;
      background: #ffebee;
    }
    #pta-complete-all-status.processing {
      color: #2196F3;
      background: #e3f2fd;
    }
  `,document.head.appendChild(t),document.body.appendChild(e),e.querySelector(`.pta-float-close`).addEventListener(`click`,()=>{e.remove()}),w()?R(e):S()||U(e),G(e)}function ee(){return`
    <div class="pta-float-header">
      <span>PTA 答题辅助</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="code-editor-container">
        <pre><code id="pta-code-highlight" class="language-c"></code></pre>
        <textarea id="pta-code-input" placeholder="请输入代码..."></textarea>
      </div>
      <div class="pta-buttons">
        <button id="pta-submit-btn">提交代码</button>
        <button id="pta-report-error-btn" class="btn-secondary">答案报错</button>
      </div>
      <div id="pta-error-section" class="error-section" style="display: none;">
        <textarea id="pta-error-note" placeholder="请输入错误备注（可选）..."></textarea>
        <button id="pta-retry-btn" class="btn-retry">重新生成</button>
      </div>
      <div id="pta-status"></div>
    </div>
  `}function R(e){let t=e.querySelector(`#pta-choice-batch-btn`);e.querySelector(`#pta-choice-results`),t&&t.addEventListener(`click`,()=>{t.textContent===`获取答案`?te(e):t.textContent===`提交`&&B(e)});let n=e.querySelector(`#pta-choice-count`);n&&window.choiceQuestions&&(n.textContent=`共 ${window.choiceQuestions.length} 题`),window.choiceQuestions&&window.choiceQuestions.length>0&&z(e)}function z(e){let t=window.choiceQuestions,n=e.querySelector(`#pta-choice-list`);if(!n||!t)return;let r=e=>String.fromCharCode(65+e),i=``;t.forEach((e,t)=>{let n=e.choices.map((e,t)=>`<span style="font-size:12px;color:#999;margin-right:6px;">${r(t)}. ${e}</span>`).join(``);i+=`<div class="choice-item" style="padding:8px 10px;border-bottom:1px solid #f5f5f5;font-size:13px;">
      <span style="color:#999;margin-right:6px;">${t+1}.</span>
      <span>${A(e.content)}</span>
      <div style="margin-top:4px;padding-left:16px;display:flex;flex-wrap:wrap;gap:4px;">${n}</div>
      <span class="choice-answer" style="color:#32F08C;font-weight:bold;float:right;display:none;"></span>
    </div>`}),n.innerHTML=i;let a=e.querySelector(`#pta-choice-batch-btn`);a&&(a.disabled=!1)}async function te(e){let t=window.choiceQuestions;if(!t||t.length===0)return;let n=e.querySelector(`#pta-choice-batch-btn`),r=e.querySelector(`#pta-choice-progress`),i=e.querySelector(`#pta-choice-progress-text`),a=e.querySelector(`#pta-choice-progress-bar`),o=e.querySelector(`#pta-choice-results`),s=e.querySelector(`#pta-choice-status`),c=e.querySelector(`#pta-choice-list`),l=await new Promise(e=>{_(e)}),u=m(l);if(!l.aiEnabled||!u){s.style.display=`block`,s.style.color=`#f44336`,s.style.background=`#ffebee`,s.textContent=`AI 未启用或未配置 API 密钥`;return}let d=l.choiceBatchSize||20,p=t.length,h=0,g={};n&&(n.textContent=`获取中`,n.disabled=!0),r.style.display=`block`;let v=e=>String.fromCharCode(65+e),y=l.choicePrompt||f.choicePrompt;for(let e=0;e<p;e+=d){let n=t.slice(e,e+d),r=n.map(e=>`题目${e.id}: ${e.content}\n选项: ${e.choices.map((e,t)=>v(t)+`. `+e).join(`, `)}`).join(`

`),s=y.replace(`{problem content}`,r);try{let e=[{role:`system`,content:s},{role:`user`,content:``}],r=(await I(u.url,u.key,u.model,e)).replace(/```[\w]*\n?/g,``).trim(),l=JSON.parse(r);if(Array.isArray(l))n.forEach((e,n)=>{let r=l[n]||`?`;g[e.id]=r;let i=c?.querySelector(`.choice-item:nth-child(${t.findIndex(t=>t.id===e.id)+1})`);if(i){let e=i.querySelector(`.choice-answer`);e&&(e.textContent=`→ `+r,e.style.display=`inline`)}});else throw Error(`AI 返回格式不正确`);h+=n.length;let d=Math.round(h/p*100);i.textContent=`${h}/${p}`,a.style.width=d+`%`,o&&(o.scrollTop=o.scrollHeight)}catch{n.forEach(e=>{let n=c?.querySelector(`.choice-item:nth-child(${t.findIndex(t=>t.id===e.id)+1})`);if(n){let e=n.querySelector(`.choice-answer`);e&&(e.textContent=`→ 解析失败`,e.style.color=`#f44336`,e.style.display=`inline`)}}),h+=n.length;let e=Math.round(h/p*100);i.textContent=`${h}/${p}`,a.style.width=e+`%`,o&&(o.scrollTop=o.scrollHeight)}}window.choiceAllAnswers=g,n&&(n.textContent=`提交`,n.disabled=!1,n.style.background=`#32F08C`),s.style.display=`block`,s.style.color=`#2196F3`,s.style.background=`#e3f2fd`,s.textContent=`答案获取完毕，共 ${p} 题，请检查后点击提交`}async function B(e){let t=window.choiceQuestions,n=window.choiceAllAnswers,r=window.choiceExamId,i=e.querySelector(`#pta-choice-status`),a=e.querySelector(`#pta-choice-batch-btn`);if(!r||!n||Object.keys(n).length===0){i.style.display=`block`,i.style.color=`#f44336`,i.style.background=`#ffebee`,i.textContent=`没有可提交的答案`;return}a&&(a.textContent=`提交中`,a.disabled=!0),i.style.display=`block`,i.style.color=`#2196F3`,i.style.background=`#e3f2fd`,i.textContent=`正在提交答案...`;try{let e=t.filter(e=>n[e.id]).map(e=>({problemId:`0`,problemSetProblemId:e.id,multipleChoiceSubmissionDetail:{answer:n[e.id]}})),o={problemType:`MULTIPLE_CHOICE`,details:e},s=await fetch(`https://pintia.cn/api/exams/${r}/exam-submissions`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`POST`,credentials:`include`,body:JSON.stringify(o)});if(s.ok)i.style.color=`#32F08C`,i.style.background=`#e8f5e9`,i.textContent=`提交成功！共 ${e.length} 题`,a&&(a.textContent=`已完成`,a.disabled=!0);else{let e=await s.json().catch(()=>({}));i.style.color=`#f44336`,i.style.background=`#ffebee`,i.textContent=`提交失败: ${s.status} ${e.error?.message||``}`,a&&(a.textContent=`提交`,a.disabled=!1)}}catch(e){i.style.color=`#f44336`,i.style.background=`#ffebee`,i.textContent=`提交失败: `+e.message,a&&(a.textContent=`提交`,a.disabled=!1)}}function V(){return`
    <div class="pta-float-header">
      <span>PTA 答题辅助 - 选择题</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div id="pta-choice-status" style="display:none;margin-bottom:12px;padding:10px;border-radius:6px;font-size:13px;text-align:center;"></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span id="pta-choice-count" style="font-size:14px;color:#666;">加载中...</span>
        <button id="pta-choice-batch-btn" class="btn-complete-all" disabled style="width:auto;padding:8px 24px;">获取答案</button>
      </div>
      <div id="pta-choice-progress" style="display:none;margin-bottom:12px;">
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#999;margin-bottom:4px;">
          <span>处理进度</span>
          <span id="pta-choice-progress-text">0/0</span>
        </div>
        <div style="width:100%;height:6px;background:#e8e8e8;border-radius:3px;overflow:hidden;">
          <div id="pta-choice-progress-bar" style="width:0%;height:100%;background:#32F08C;border-radius:3px;transition:width 0.3s;"></div>
        </div>
      </div>
      <div id="pta-choice-results" style="max-height:400px;overflow-y:auto;">
        <div id="pta-choice-list" style="text-align:center;padding:20px;color:#999;">加载中...</div>
      </div>
    </div>
  `}function H(){return`
    <div class="pta-float-header">
      <span>PTA 答题辅助 - 题目列表</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="pta-buttons">
        <button id="pta-complete-all-btn" class="btn-complete-all">一键完成所有题目</button>
      </div>
      <div id="pta-problem-list" class="problem-list">
        <div class="problem-item">
          <span class="problem-index">加载中...</span>
          <span class="problem-title">正在获取题目列表...</span>
        </div>
      </div>
      <div id="pta-problem-list-status"></div>
      <div id="pta-complete-all-status" style="display: none;"></div>
    </div>
  `}function U(e){let t=e.querySelector(`#pta-code-input`),n=e.querySelector(`#pta-code-highlight`),r=null;t.addEventListener(`input`,function(){n.innerHTML=A(t.value),r&&clearTimeout(r),r=setTimeout(()=>{c.default.highlightElement(n)},300)}),t.addEventListener(`scroll`,function(){n.parentElement.scrollTop=t.scrollTop,n.parentElement.scrollLeft=t.scrollLeft});let i=e.querySelector(`#pta-submit-btn`),a=e.querySelector(`#pta-status`);i.addEventListener(`click`,async()=>{let e=t.value.trim();if(!e){a.textContent=`请输入代码`,a.className=`error`;return}i.disabled=!0,a.textContent=`提交中...`,a.className=``;let n=await q(e);i.disabled=!1,n.success?(a.textContent=`提交成功！`,a.className=`success`,n.examId&&n.submissionId&&J(a,n.examId,n.submissionId)):(a.textContent=n.error||`提交失败`,a.className=`error`,j())});let o=e.querySelector(`#pta-report-error-btn`),s=e.querySelector(`#pta-error-section`);o.addEventListener(`click`,()=>{s.style.display=s.style.display===`none`?`block`:`none`});let l=e.querySelector(`#pta-retry-btn`),u=e.querySelector(`#pta-error-note`);l.addEventListener(`click`,async()=>{let e=u.value.trim();l.disabled=!0,l.textContent=`重新生成中...`,a.textContent=`正在重新生成代码...`,a.className=``,await k(h,!0,e),l.disabled=!1,l.textContent=`重新生成`,a.textContent=`代码已重新生成！`,a.className=`success`,s.style.display=`none`,u.value=``})}function W(){let e=document.getElementById(`pta-helper-float`);e&&e.remove()}function G(e){let t=e.querySelector(`.pta-float-header`),n=!1,r,i,a,o,s=0,c=0;t.addEventListener(`mousedown`,l),document.addEventListener(`mouseup`,u),document.addEventListener(`mousemove`,d);function l(e){a=e.clientX-s,o=e.clientY-c,(e.target===t||e.target.tagName===`SPAN`)&&(n=!0)}function u(){a=r,o=i,n=!1}function d(t){n&&(t.preventDefault(),r=t.clientX-a,i=t.clientY-o,s=r,c=i,e.style.transform=`translate(${r}px, ${i}px)`)}}function K(){let e=localStorage.getItem(`x-lollipop`)||``;if(!e){let t=document.cookie.match(/x-lollipop=([^;]+)/);t&&(e=t[1])}return e}async function q(e,t=null,n=null){try{let r=window.location.href,i=t,a=n;if(!i||!a){let e=r.match(/problemSetProblemId=(\d+)/);a=e?e[1]:null;let t=r.match(/\/problem-sets\/(\d+)/);if(i=t?t[1]:null,(!a||!i)&&r.match(/\/exam\/submissions\/(\d+)/)&&window.currentSubmissionData&&(a=window.currentSubmissionData.submission.problemSetProblemId,i=window.currentSubmissionData.submission.problemSetId),!a||!i)return{success:!1,error:`无法获取页面信息`}}let o=null,s=await fetch(`https://pintia.cn/api/problem-sets/${i}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(s.ok){let e=await s.json();e&&e.exam&&e.exam.id&&(o=e.exam.id)}if(!o)return{success:!1,error:`无法获取 exam ID`};let c=`https://pintia.cn/api/exams/${o}/exam-submissions`,l=C(),u={problemType:l,details:[{problemId:`0`,problemSetProblemId:a,[l===`CODE_COMPLETION`?`codeCompletionSubmissionDetail`:`programmingSubmissionDetail`]:{program:e,compiler:`GCC`}}]},d=await fetch(c,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},referrer:r,body:JSON.stringify(u),method:`POST`,mode:`cors`,credentials:`include`}),f=await d.json();if(d.ok){let e=typeof f==`object`&&f.submissionId?f.submissionId:typeof f==`string`?f:null;return{success:!0,data:f,examId:o,submissionId:e}}else if(d.status===429){let t=5e3+Math.random()*5e3;return await new Promise(e=>setTimeout(e,t)),q(e,i,a)}else return{success:!1,error:f.message||`提交失败`}}catch{let t=5e3+Math.random()*5e3;return await new Promise(e=>setTimeout(e,t)),q(e,localProblemSetId,localProblemSetProblemId)}}async function J(e,t,n){let r={ACCEPTED:`#32F08C`,PARTIAL_ACCEPTED:`#ff9800`,WRONG_ANSWER:`#f44336`,COMPILE_ERROR:`#f44336`,SEGMENTATION_FAULT:`#f44336`,RUNTIME_ERROR:`#f44336`,WAITING:`#999`,RUNNING:`#2196F3`,PRESENTATION_ERROR:`#ff9800`,TIME_LIMIT_EXCEEDED:`#f44336`,MEMORY_LIMIT_EXCEEDED:`#f44336`,OUTPUT_LIMIT_EXCEEDED:`#f44336`};for(let i=0;i<10;i++)try{i===0?e.textContent=`正在获取结果...`:(e.textContent=`判题中 (${i}/9)...`,await new Promise(e=>setTimeout(e,5e3)));let a=`https://pintia.cn/api/exams/${t}/submissions/${n}`,o=await fetch(a,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!o.ok){console.log(`轮询提交结果 [${i+1}/10] HTTP ${o.status}`);continue}let s=await o.json();console.log(`提交结果 [${i+1}/10]:`,s);let c=s?.submission,l=c?.status;if(!l)continue;if(l===`WAITING`||l===`RUNNING`||l===`JUDGING`||l===`PROGRAMMING_JUDGING`){e.textContent=l===`WAITING`?`排队等待中...`:`判题中...`,e.className=``;continue}let u=c?.judgeResponseContents?.[0],d=u?.programmingJudgeResponseContent||u?.codeCompletionJudgeResponseContent,f=d?.testcaseJudgeResults||{};if(l===`COMPILE_ERROR`){let t=d?.compilationResult?.log||``;e.innerHTML=`<span style="color:${r[l]};font-weight:bold;">COMPILE_ERROR</span>`,t&&console.log(`编译错误日志:`,t),e.className=`error`;return}let p=Object.values(f),m=p.length,h=p.filter(e=>e.result===`ACCEPTED`).length,g=l;m>0&&(g=`${h}/${m} ${l}`),e.innerHTML=`<span style="color:${r[l]||`#f44336`};font-weight:bold;">${g}</span>`,e.className=m>0&&h===m?`success`:l===`PARTIAL_ACCEPTED`?``:`error`;return}catch(e){console.log(`轮询提交结果 [${i+1}/10] 出错:`,e.message)}e.textContent=`提交成功（判题超时）`,e.className=`success`}async function Y(e,t,n){let r={ACCEPTED:`#32F08C`,PARTIAL_ACCEPTED:`#ff9800`,WRONG_ANSWER:`#f44336`,COMPILE_ERROR:`#f44336`,SEGMENTATION_FAULT:`#f44336`},i={ACCEPTED:`AC`,PARTIAL_ACCEPTED:`PA`,WRONG_ANSWER:`WA`,COMPILE_ERROR:`CE`,SEGMENTATION_FAULT:`SF`};e.textContent=`等待结果`,e.style.background=`#ff9800`,e.disabled=!0;for(let a=0;a<10;a++)try{a>0&&await new Promise(e=>setTimeout(e,5e3));let o=`https://pintia.cn/api/exams/${t}/submissions/${n}`,s=await fetch(o,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!s.ok)continue;let c=(await s.json())?.submission,l=c?.status;if(!l)continue;if(l===`WAITING`||l===`RUNNING`||l===`JUDGING`||l===`PROGRAMMING_JUDGING`){e.textContent=`判题中`,e.style.background=`#999`;continue}let u=c?.judgeResponseContents?.[0],d=(u?.programmingJudgeResponseContent||u?.codeCompletionJudgeResponseContent)?.testcaseJudgeResults||{},f=Object.values(d),p=f.length,m=f.filter(e=>e.result===`ACCEPTED`).length,h=i[l]||l;return e.textContent=p>0?`${m}/${p} ${h}`:h,e.style.background=r[l]||`#999`,e.disabled=!1,l}catch{}return e.textContent=`超时`,e.style.background=`#999`,e.disabled=!1,`TIMEOUT`}var X=window.location.href;setInterval(()=>{Z()},1e3),window.addEventListener(`popstate`,function(){Z()}),window.addEventListener(`hashchange`,function(){Z()});function Z(){if(window.location.href!==X&&(X=window.location.href,d(`URL 变化`,{url:X,isProgrammingListPage:S(),isProgrammingDetailPage:x(),isChoiceQuestionPage:w(),isSubmissionResultPage:T()}),v(),!T())){let e=document.getElementById(`pta-helper-result-float`);e&&e.remove()}}window.addEventListener(`load`,function(){Z()}),v(),Q();async function Q(){try{let e=(await new Promise(e=>{chrome.storage.local.get([`ignoredVersion`],e)})).ignoredVersion||`0.0.0`,t=null;try{let e=await fetch(`https://raw.githubusercontent.com/lmengx/fuckpta/main/ver.json`,{cache:`no-cache`});e.ok&&(t=await e.json())}catch{}if(!t)try{let e=await fetch(`https://gitee.com/lmx12330/fuckpta/raw/main/ver.json`,{cache:`no-cache`});e.ok&&(t=await e.json())}catch{}if(!t||!t.version)return;let n=t.version,r=chrome.runtime.getManifest().version;if($(r,n)>=0||$(e,n)>=0)return;ne(n,t.changes||[])}catch{}}function $(e,t){let n=e.split(`.`).map(Number),r=t.split(`.`).map(Number),i=Math.max(n.length,r.length);for(let e=0;e<i;e++){let t=n[e]||0,i=r[e]||0;if(t<i)return-1;if(t>i)return 1}return 0}function ne(e,t){let n=document.createElement(`div`);n.id=`pta-version-overlay`,n.style.cssText=`position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;z-index:9999999;backdrop-filter:blur(4px);`;let r=t.length?`<ul style="margin-top:12px;padding-left:20px;font-size:13px;color:#888;line-height:1.8;text-align:left;">`+t.map(e=>`<li style="list-style:disc;">`+A(e)+`</li>`).join(``)+`</ul>`:``;n.innerHTML=`<div style="background:#fff;border-radius:16px;padding:40px;width:460px;max-width:90%;box-shadow:0 8px 40px rgba(0,0,0,0.25);text-align:center;animation:fadeInUp 0.4s ease;"><h2 style="font-size:22px;color:#1a1a1a;margin:0 0 8px;">🎉 发现新版本</h2><p style="font-size:32px;font-weight:700;color:#32F08C;margin:8px 0;">v`+A(e)+`</p>`+r+`<div style="display:flex;gap:12px;margin-top:24px;justify-content:center;"><button id="pta-ver-update-btn" style="padding:12px 32px;border:none;border-radius:8px;background:#32F08C;color:#fff;font-size:15px;font-weight:600;cursor:pointer;">前往更新</button><button id="pta-ver-ignore-btn" style="padding:12px 32px;border:1px solid #d9d9d9;border-radius:8px;background:#fff;color:#666;font-size:15px;cursor:pointer;">忽略此版本</button></div></div>`;let i=document.createElement(`style`);i.textContent=`@keyframes fadeInUp{from{opacity:0;transform:translateY(30px);}to{opacity:1;transform:translateY(0);}}`,n.appendChild(i),document.body.appendChild(n),n.querySelector(`#pta-ver-update-btn`).addEventListener(`click`,()=>{window.open(`https://gitee.com/lmx12330/fuckpta/releases/`,`_blank`)}),n.querySelector(`#pta-ver-ignore-btn`).addEventListener(`click`,()=>{chrome.storage.local.set({ignoredVersion:e}),n.remove()})}async function re(){if(!T())return null;try{let e=window.location.href,t=e.match(/\/exam\/submissions\/(\d+)/);if(!t)return u(`无法从URL中提取提交ID`,`error`),null;let n=`https://pintia.cn/api/submissions/${t[1]}?`,r=await fetch(n,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,priority:`u=1, i`,"sec-ch-ua":`"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"`,"sec-ch-ua-mobile":`?0`,"sec-ch-ua-platform":`"Windows"`,"sec-fetch-dest":`empty`,"sec-fetch-mode":`cors`,"sec-fetch-site":`same-origin`,"x-lollipop":K(),"x-marshmallow":``},referrer:e,body:null,method:`GET`,mode:`cors`,credentials:`include`});if(!r.ok)return u(`API请求失败: ${r.status} ${r.statusText}`,`error`),null;let i=await r.json();return window.currentSubmissionData=i,ie(),i}catch(e){return u(`获取提交结果数据时出错: ${e.message}`,`error`),null}}function ie(){if(document.getElementById(`pta-helper-result-float`))return;let e=document.createElement(`div`);e.id=`pta-helper-result-float`,e.innerHTML=`
    <div class="pta-float-header">
      <span>PTA 答题辅助 - 结果分析</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="pta-result-info">
        <div id="pta-result-status"></div>
      </div>
      <div class="pta-buttons">
        <button id="pta-get-answer-btn">获取答案</button>
      </div>
      <div id="pta-ai-result" style="display: none;">
        <h4>AI 生成的答案</h4>
        <div class="code-editor-container">
          <pre><code id="pta-ai-code-highlight" class="language-c"></code></pre>
          <textarea id="pta-ai-code" placeholder="AI 生成的代码将显示在这里..." readonly></textarea>
        </div>
        <div class="pta-buttons">
          <button id="pta-copy-btn">一键复制</button>
          <button id="pta-submit-btn">一键提交</button>
        </div>
      </div>
      <div id="pta-status"></div>
    </div>
  `;let t=document.createElement(`style`);t.textContent=`
    #pta-helper-result-float {
      position: fixed;
      top: 50px;
      right: 20px;
      width: 500px;
      max-height: 80vh;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: Arial, sans-serif;
      overflow-y: auto;
    }
    .pta-float-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: #4CAF50;
      color: white;
      border-radius: 8px 8px 0 0;
      cursor: move;
      position: sticky;
      top: 0;
      z-index: 1;
    }
    .pta-float-header span {
      font-weight: bold;
      font-size: 16px;
    }
    .pta-float-close {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pta-float-close:hover {
      background: rgba(255,255,255,0.2);
      border-radius: 4px;
    }
    .pta-float-body {
      padding: 20px;
    }
    .pta-result-info {
      margin-bottom: 20px;
    }
    #pta-result-status {
      font-size: 14px;
      line-height: 1.5;
    }
    .pta-buttons {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-top: 15px;
    }
    #pta-get-answer-btn, #pta-copy-btn, #pta-submit-btn {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    #pta-get-answer-btn {
      background: #4CAF50;
      color: white;
    }
    #pta-get-answer-btn:hover {
      background: #45a049;
    }
    #pta-get-answer-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-copy-btn {
      background: #2196F3;
      color: white;
    }
    #pta-copy-btn:hover {
      background: #1976D2;
    }
    #pta-submit-btn {
      background: #ff9800;
      color: white;
    }
    #pta-submit-btn:hover {
      background: #f57c00;
    }
    #pta-ai-result {
      margin-top: 20px;
    }
    #pta-ai-result h4 {
      margin-top: 0;
      margin-bottom: 10px;
      color: #333;
    }
    .code-editor-container {
      position: relative;
      width: 100%;
      height: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
      overflow: hidden;
    }
    .code-editor-container pre {
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      padding: 12px;
      width: 100%;
      height: 100%;
      background: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      overflow: auto;
      pointer-events: none;
      white-space: pre;
    }
    .code-editor-container code {
      font-family: 'Courier New', monospace;
    }
    #pta-ai-code {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      padding: 12px;
      border: none;
      background: transparent;
      color: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      resize: none;
      box-sizing: border-box;
      z-index: 1;
      white-space: pre;
      overflow: auto;
    }
    #pta-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-status.error {
      color: #f44336;
      background: #ffebee;
    }
  `,document.head.appendChild(t),document.body.appendChild(e);let n=e.querySelector(`#pta-ai-code`),r=e.querySelector(`#pta-ai-code-highlight`);n.addEventListener(`scroll`,function(){r.parentElement.scrollTop=n.scrollTop,r.parentElement.scrollLeft=n.scrollLeft}),e.querySelector(`.pta-float-close`).addEventListener(`click`,()=>{e.remove()});let i=e.querySelector(`#pta-get-answer-btn`),a=e.querySelector(`#pta-ai-result`),o=e.querySelector(`#pta-status`);i.addEventListener(`click`,async()=>{if(!window.currentSubmissionData){o.textContent=`未找到提交结果数据`,o.className=`error`;return}i.disabled=!0,i.textContent=`获取中...`,o.textContent=`正在获取答案...`,o.className=``;try{let e=``,t=``,s=``,l=``;if(window.currentSubmissionData&&window.currentSubmissionData.submission&&window.currentSubmissionData.submission.submissionDetails&&window.currentSubmissionData.submission.submissionDetails.length>0){let t=window.currentSubmissionData.submission.submissionDetails[0];t.programmingSubmissionDetail&&t.programmingSubmissionDetail.program?e=t.programmingSubmissionDetail.program:t.codeCompletionSubmissionDetail&&t.codeCompletionSubmissionDetail.program&&(e=t.codeCompletionSubmissionDetail.program)}if(window.currentSubmissionData&&window.currentSubmissionData.submission&&window.currentSubmissionData.submission.status&&(t=window.currentSubmissionData.submission.status),window.currentSubmissionData&&window.currentSubmissionData.submission&&window.currentSubmissionData.submission.judgeResponseContents&&window.currentSubmissionData.submission.judgeResponseContents.length>0){let e=window.currentSubmissionData.submission.judgeResponseContents[0],t=e.programmingJudgeResponseContent||e.codeCompletionJudgeResponseContent;t&&t.compilationResult&&(s=t.compilationResult.log||``)}if(window.currentSubmissionData&&window.currentSubmissionData.submission){let e=window.currentSubmissionData.submission.hints||{},t=window.currentSubmissionData.submission.judgeResponseContents&&window.currentSubmissionData.submission.judgeResponseContents.length>0?window.currentSubmissionData.submission.judgeResponseContents[0]:null,n=t?t.programmingJudgeResponseContent||t.codeCompletionJudgeResponseContent:null,r=n&&n.testcaseJudgeResults||{},i=[];for(let t in e)if(e.hasOwnProperty(t)){let n={序号:t,提示:e[t],结果:r[t]?r[t].result:`未知`};i.push(n)}l=JSON.stringify(i,null,2)}let u=window.currentSubmissionData.submission.problemSetProblemId,f=window.currentSubmissionData.submission.problemSetId;if(!u||!f){o.textContent=`无法获取题目信息`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let p=`https://pintia.cn/api/problem-sets/${f}/exam-problems/${u}`,h=await fetch(p,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":K(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!h.ok){o.textContent=`获取题目信息失败`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let g=await h.json(),v=``;g&&g.problemSetProblem&&(v=g.problemSetProblem.content||g.problemSetProblem.description||``),_(async function(u){let f=m(u);if(!u.aiEnabled||!f){o.textContent=`AI 未启用或未配置 API 密钥`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let p=[{role:`system`,content:(u.aiErrorPrompt||`你是专业的编程题 AC 生成器。
语言：{language}
错误类型：{error_type}
编译器提示：{compiler_msg}
测试点提示：{data_tip}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。
题目如下：
{problem content}
错误源码如下：
{res_code}`).replace(`{language}`,u.language).replace(`{error_type}`,t).replace(`{compiler_msg}`,s).replace(`{data_tip}`,l).replace(`{problem content}`,v).replace(`{res_code}`,e)}];d(`发给 AI 的内容（纠错功能）`,p);let h=``;a.style.display=`block`;let g=null,_=0;await F(f.url,f.key,f.model,p,e=>{h+=e;let t=h.replace(/```[\w]*\n?/g,``).trim();n.value=t,r.innerHTML=A(t);let i=Date.now(),a=t.length>5e3?2e3:500;i-_>=a?(c.default.highlightElement(r),_=i):(g&&clearTimeout(g),g=setTimeout(()=>{c.default.highlightElement(r),_=Date.now()},a))},()=>{g&&clearTimeout(g),c.default.highlightElement(r),d(`AI 返回的内容（纠错功能）`,h),o.textContent=`答案获取成功！`,o.className=`success`,i.disabled=!1,i.textContent=`获取答案`},e=>{o.textContent=`AI 调用失败: `+(e.message||`未知错误`),o.className=`error`,i.disabled=!1,i.textContent=`获取答案`}),h||(o.textContent=`AI 未返回有效结果`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`)})}catch(e){o.textContent=`获取答案时出错: `+e.message,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`}}),e.querySelector(`#pta-copy-btn`).addEventListener(`click`,()=>{let e=n.value;if(!e){o.textContent=`没有可复制的代码`,o.className=`error`;return}navigator.clipboard.writeText(e).then(()=>{o.textContent=`代码已复制到剪贴板！`,o.className=`success`}).catch(e=>{o.textContent=`复制失败: `+e.message,o.className=`error`})}),e.querySelector(`#pta-submit-btn`).addEventListener(`click`,async()=>{let e=n.value;if(!e){o.textContent=`没有可提交的代码`,o.className=`error`;return}o.textContent=`正在提交代码...`,o.className=`info`;try{console.log(`当前URL:`,window.location.href);let t=await q(e);t.success?(o.textContent=`代码提交成功！`,o.className=`success`,t.examId&&t.submissionId&&J(o,t.examId,t.submissionId)):(o.textContent=`提交失败: `+t.error,o.className=`error`)}catch(e){o.textContent=`提交出错: `+e.message,o.className=`error`}}),G(e)}try{chrome.runtime.onMessage.addListener((e,t,n)=>{try{if(e.action===`submitCode`)return q(e.code).then(e=>{try{n(e)}catch(e){console.warn(`发送响应时出错:`,e)}}),!0;if(e.action===`extractProblem`)return O().then(()=>{try{n({success:!0})}catch(e){console.warn(`发送响应时出错:`,e)}}).catch(e=>{try{n({success:!1,error:e.message})}catch(e){console.warn(`发送响应时出错:`,e)}}),!0;if(e.action===`generateCode`){if(h)k(h).then(()=>{try{n({success:!0})}catch(e){console.warn(`发送响应时出错:`,e)}}).catch(e=>{try{n({success:!1,error:e.message})}catch(e){console.warn(`发送响应时出错:`,e)}});else try{n({success:!1,error:`未提取到题目内容`})}catch(e){console.warn(`发送响应时出错:`,e)}return!0}else if(e.action===`autoSubmit`){let e=document.getElementById(`pta-code-input`);if(e){let t=e.value.trim();if(t)q(t).then(e=>{try{n(e)}catch(e){console.warn(`发送响应时出错:`,e)}});else try{n({success:!1,error:`代码为空`})}catch(e){console.warn(`发送响应时出错:`,e)}}else try{n({success:!1,error:`未找到代码输入框`})}catch(e){console.warn(`发送响应时出错:`,e)}return!0}}catch(e){console.warn(`处理消息时出错:`,e);try{n({success:!1,error:e.message})}catch(e){console.warn(`发送响应时出错:`,e)}return!0}})}catch(e){console.warn(`注册消息监听器时出错:`,e)}})()
