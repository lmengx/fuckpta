(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=((n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n)))(o(((e,t)=>{var n=function(e){var t=/(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i,n=0,r={},i={manual:e.Prism&&e.Prism.manual,disableWorkerMessageHandler:e.Prism&&e.Prism.disableWorkerMessageHandler,util:{encode:function e(t){return t instanceof a?new a(t.type,e(t.content),t.alias):Array.isArray(t)?t.map(e):t.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/\u00a0/g,` `)},type:function(e){return Object.prototype.toString.call(e).slice(8,-1)},objId:function(e){return e.__id||Object.defineProperty(e,`__id`,{value:++n}),e.__id},clone:function e(t,n){n||={};var r,a;switch(i.util.type(t)){case`Object`:if(a=i.util.objId(t),n[a])return n[a];for(var o in r={},n[a]=r,t)t.hasOwnProperty(o)&&(r[o]=e(t[o],n));return r;case`Array`:return a=i.util.objId(t),n[a]?n[a]:(r=[],n[a]=r,t.forEach(function(t,i){r[i]=e(t,n)}),r);default:return t}},getLanguage:function(e){for(;e;){var n=t.exec(e.className);if(n)return n[1].toLowerCase();e=e.parentElement}return`none`},setLanguage:function(e,n){e.className=e.className.replace(RegExp(t,`gi`),``),e.classList.add(`language-`+n)},currentScript:function(){if(typeof document>`u`)return null;if(document.currentScript&&document.currentScript.tagName===`SCRIPT`)return document.currentScript;try{throw Error()}catch(r){var e=(/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(r.stack)||[])[1];if(e){var t=document.getElementsByTagName(`script`);for(var n in t)if(t[n].src==e)return t[n]}return null}},isActive:function(e,t,n){for(var r=`no-`+t;e;){var i=e.classList;if(i.contains(t))return!0;if(i.contains(r))return!1;e=e.parentElement}return!!n}},languages:{plain:r,plaintext:r,text:r,txt:r,extend:function(e,t){var n=i.util.clone(i.languages[e]);for(var r in t)n[r]=t[r];return n},insertBefore:function(e,t,n,r){r||=i.languages;var a=r[e],o={};for(var s in a)if(a.hasOwnProperty(s)){if(s==t)for(var c in n)n.hasOwnProperty(c)&&(o[c]=n[c]);n.hasOwnProperty(s)||(o[s]=a[s])}var l=r[e];return r[e]=o,i.languages.DFS(i.languages,function(t,n){n===l&&t!=e&&(this[t]=o)}),o},DFS:function e(t,n,r,a){a||={};var o=i.util.objId;for(var s in t)if(t.hasOwnProperty(s)){n.call(t,s,t[s],r||s);var c=t[s],l=i.util.type(c);l===`Object`&&!a[o(c)]?(a[o(c)]=!0,e(c,n,null,a)):l===`Array`&&!a[o(c)]&&(a[o(c)]=!0,e(c,n,s,a))}}},plugins:{},highlightAll:function(e,t){i.highlightAllUnder(document,e,t)},highlightAllUnder:function(e,t,n){var r={callback:n,container:e,selector:`code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code`};i.hooks.run(`before-highlightall`,r),r.elements=Array.prototype.slice.apply(r.container.querySelectorAll(r.selector)),i.hooks.run(`before-all-elements-highlight`,r);for(var a=0,o;o=r.elements[a++];)i.highlightElement(o,t===!0,r.callback)},highlightElement:function(t,n,r){var a=i.util.getLanguage(t),o=i.languages[a];i.util.setLanguage(t,a);var s=t.parentElement;s&&s.nodeName.toLowerCase()===`pre`&&i.util.setLanguage(s,a);var c={element:t,language:a,grammar:o,code:t.textContent};function l(e){c.highlightedCode=e,i.hooks.run(`before-insert`,c),c.element.innerHTML=c.highlightedCode,i.hooks.run(`after-highlight`,c),i.hooks.run(`complete`,c),r&&r.call(c.element)}if(i.hooks.run(`before-sanity-check`,c),s=c.element.parentElement,s&&s.nodeName.toLowerCase()===`pre`&&!s.hasAttribute(`tabindex`)&&s.setAttribute(`tabindex`,`0`),!c.code){i.hooks.run(`complete`,c),r&&r.call(c.element);return}if(i.hooks.run(`before-highlight`,c),!c.grammar){l(i.util.encode(c.code));return}if(n&&e.Worker){var u=new Worker(i.filename);u.onmessage=function(e){l(e.data)},u.postMessage(JSON.stringify({language:c.language,code:c.code,immediateClose:!0}))}else l(i.highlight(c.code,c.grammar,c.language))},highlight:function(e,t,n){var r={code:e,grammar:t,language:n};if(i.hooks.run(`before-tokenize`,r),!r.grammar)throw Error(`The language "`+r.language+`" has no grammar.`);return r.tokens=i.tokenize(r.code,r.grammar),i.hooks.run(`after-tokenize`,r),a.stringify(i.util.encode(r.tokens),r.language)},tokenize:function(e,t){var n=t.rest;if(n){for(var r in n)t[r]=n[r];delete t.rest}var i=new c;return l(i,i.head,e),s(e,i,t,i.head,0),d(i)},hooks:{all:{},add:function(e,t){var n=i.hooks.all;n[e]=n[e]||[],n[e].push(t)},run:function(e,t){var n=i.hooks.all[e];if(!(!n||!n.length))for(var r=0,a;a=n[r++];)a(t)}},Token:a};e.Prism=i;function a(e,t,n,r){this.type=e,this.content=t,this.alias=n,this.length=(r||``).length|0}a.stringify=function e(t,n){if(typeof t==`string`)return t;if(Array.isArray(t)){var r=``;return t.forEach(function(t){r+=e(t,n)}),r}var a={type:t.type,content:e(t.content,n),tag:`span`,classes:[`token`,t.type],attributes:{},language:n},o=t.alias;o&&(Array.isArray(o)?Array.prototype.push.apply(a.classes,o):a.classes.push(o)),i.hooks.run(`wrap`,a);var s=``;for(var c in a.attributes)s+=` `+c+`="`+(a.attributes[c]||``).replace(/"/g,`&quot;`)+`"`;return`<`+a.tag+` class="`+a.classes.join(` `)+`"`+s+`>`+a.content+`</`+a.tag+`>`};function o(e,t,n,r){e.lastIndex=t;var i=e.exec(n);if(i&&r&&i[1]){var a=i[1].length;i.index+=a,i[0]=i[0].slice(a)}return i}function s(e,t,n,r,c,d){for(var f in n)if(!(!n.hasOwnProperty(f)||!n[f])){var p=n[f];p=Array.isArray(p)?p:[p];for(var m=0;m<p.length;++m){if(d&&d.cause==f+`,`+m)return;var h=p[m],g=h.inside,_=!!h.lookbehind,v=!!h.greedy,y=h.alias;if(v&&!h.pattern.global){var b=h.pattern.toString().match(/[imsuy]*$/)[0];h.pattern=RegExp(h.pattern.source,b+`g`)}for(var x=h.pattern||h,S=r.next,C=c;S!==t.tail&&!(d&&C>=d.reach);C+=S.value.length,S=S.next){var w=S.value;if(t.length>e.length)return;if(!(w instanceof a)){var T=1,E;if(v){if(E=o(x,C,e,_),!E||E.index>=e.length)break;var D=E.index,O=E.index+E[0].length,k=C;for(k+=S.value.length;D>=k;)S=S.next,k+=S.value.length;if(k-=S.value.length,C=k,S.value instanceof a)continue;for(var A=S;A!==t.tail&&(k<O||typeof A.value==`string`);A=A.next)T++,k+=A.value.length;T--,w=e.slice(C,k),E.index-=C}else if(E=o(x,0,w,_),!E)continue;var D=E.index,j=E[0],M=w.slice(0,D),N=w.slice(D+j.length),P=C+w.length;d&&P>d.reach&&(d.reach=P);var F=S.prev;M&&(F=l(t,F,M),C+=M.length),u(t,F,T);var I=new a(f,g?i.tokenize(j,g):j,y,j);if(S=l(t,F,I),N&&l(t,S,N),T>1){var L={cause:f+`,`+m,reach:P};s(e,t,n,S.prev,C,L),d&&L.reach>d.reach&&(d.reach=L.reach)}}}}}}function c(){var e={value:null,prev:null,next:null},t={value:null,prev:e,next:null};e.next=t,this.head=e,this.tail=t,this.length=0}function l(e,t,n){var r=t.next,i={value:n,prev:t,next:r};return t.next=i,r.prev=i,e.length++,i}function u(e,t,n){for(var r=t.next,i=0;i<n&&r!==e.tail;i++)r=r.next;t.next=r,r.prev=t,e.length-=i}function d(e){for(var t=[],n=e.head.next;n!==e.tail;)t.push(n.value),n=n.next;return t}if(!e.document)return e.addEventListener&&(i.disableWorkerMessageHandler||e.addEventListener(`message`,function(t){var n=JSON.parse(t.data),r=n.language,a=n.code,o=n.immediateClose;e.postMessage(i.highlight(a,i.languages[r],r)),o&&e.close()},!1)),i;var f=i.util.currentScript();f&&(i.filename=f.src,f.hasAttribute(`data-manual`)&&(i.manual=!0));function p(){i.manual||i.highlightAll()}if(!i.manual){var m=document.readyState;m===`loading`||m===`interactive`&&f&&f.defer?document.addEventListener(`DOMContentLoaded`,p):window.requestAnimationFrame?window.requestAnimationFrame(p):window.setTimeout(p,16)}return i}(typeof window<`u`?window:typeof WorkerGlobalScope<`u`&&self instanceof WorkerGlobalScope?self:{});t!==void 0&&t.exports&&(t.exports=n),typeof global<`u`&&(global.Prism=n),n.languages.markup={comment:{pattern:/<!--(?:(?!<!--)[\s\S])*?-->/,greedy:!0},prolog:{pattern:/<\?[\s\S]+?\?>/,greedy:!0},doctype:{pattern:/<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,greedy:!0,inside:{"internal-subset":{pattern:/(^[^\[]*\[)[\s\S]+(?=\]>$)/,lookbehind:!0,greedy:!0,inside:null},string:{pattern:/"[^"]*"|'[^']*'/,greedy:!0},punctuation:/^<!|>$|[[\]]/,"doctype-tag":/^DOCTYPE/i,name:/[^\s<>'"]+/}},cdata:{pattern:/<!\[CDATA\[[\s\S]*?\]\]>/i,greedy:!0},tag:{pattern:/<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,greedy:!0,inside:{tag:{pattern:/^<\/?[^\s>\/]+/,inside:{punctuation:/^<\/?/,namespace:/^[^\s>\/:]+:/}},"special-attr":[],"attr-value":{pattern:/=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,inside:{punctuation:[{pattern:/^=/,alias:`attr-equals`},{pattern:/^(\s*)["']|["']$/,lookbehind:!0}]}},punctuation:/\/?>/,"attr-name":{pattern:/[^\s>\/]+/,inside:{namespace:/^[^\s>\/:]+:/}}}},entity:[{pattern:/&[\da-z]{1,8};/i,alias:`named-entity`},/&#x?[\da-f]{1,8};/i]},n.languages.markup.tag.inside[`attr-value`].inside.entity=n.languages.markup.entity,n.languages.markup.doctype.inside[`internal-subset`].inside=n.languages.markup,n.hooks.add(`wrap`,function(e){e.type===`entity`&&(e.attributes.title=e.content.replace(/&amp;/,`&`))}),Object.defineProperty(n.languages.markup.tag,`addInlined`,{value:function(e,t){var r={};r[`language-`+t]={pattern:/(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,lookbehind:!0,inside:n.languages[t]},r.cdata=/^<!\[CDATA\[|\]\]>$/i;var i={"included-cdata":{pattern:/<!\[CDATA\[[\s\S]*?\]\]>/i,inside:r}};i[`language-`+t]={pattern:/[\s\S]+/,inside:n.languages[t]};var a={};a[e]={pattern:RegExp(`(<__[^>]*>)(?:<!\\[CDATA\\[(?:[^\\]]|\\](?!\\]>))*\\]\\]>|(?!<!\\[CDATA\\[)[\\s\\S])*?(?=<\\/__>)`.replace(/__/g,function(){return e}),`i`),lookbehind:!0,greedy:!0,inside:i},n.languages.insertBefore(`markup`,`cdata`,a)}}),Object.defineProperty(n.languages.markup.tag,`addAttribute`,{value:function(e,t){n.languages.markup.tag.inside[`special-attr`].push({pattern:RegExp(`(^|["'\\s])(?:`+e+`)\\s*=\\s*(?:"[^"]*"|'[^']*'|[^\\s'">=]+(?=[\\s>]))`,`i`),lookbehind:!0,inside:{"attr-name":/^[^\s=]+/,"attr-value":{pattern:/=[\s\S]+/,inside:{value:{pattern:/(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,lookbehind:!0,alias:[t,`language-`+t],inside:n.languages[t]},punctuation:[{pattern:/^=/,alias:`attr-equals`},/"|'/]}}}})}}),n.languages.html=n.languages.markup,n.languages.mathml=n.languages.markup,n.languages.svg=n.languages.markup,n.languages.xml=n.languages.extend(`markup`,{}),n.languages.ssml=n.languages.xml,n.languages.atom=n.languages.xml,n.languages.rss=n.languages.xml,(function(e){var t=/(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;e.languages.css={comment:/\/\*[\s\S]*?\*\//,atrule:{pattern:RegExp(`@[\\w-](?:[^;{\\s"']|\\s+(?!\\s)|`+t.source+`)*?(?:;|(?=\\s*\\{))`),inside:{rule:/^@[\w-]+/,"selector-function-argument":{pattern:/(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,lookbehind:!0,alias:`selector`},keyword:{pattern:/(^|[^\w-])(?:and|not|only|or)(?![\w-])/,lookbehind:!0}}},url:{pattern:RegExp(`\\burl\\((?:`+t.source+`|(?:[^\\\\\\r\\n()"']|\\\\[\\s\\S])*)\\)`,`i`),greedy:!0,inside:{function:/^url/i,punctuation:/^\(|\)$/,string:{pattern:RegExp(`^`+t.source+`$`),alias:`url`}}},selector:{pattern:RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|`+t.source+`)*(?=\\s*\\{)`),lookbehind:!0},string:{pattern:t,greedy:!0},property:{pattern:/(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,lookbehind:!0},important:/!important\b/i,function:{pattern:/(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,lookbehind:!0},punctuation:/[(){};:,]/},e.languages.css.atrule.inside.rest=e.languages.css;var n=e.languages.markup;n&&(n.tag.addInlined(`style`,`css`),n.tag.addAttribute(`style`,`css`))})(n),n.languages.clike={comment:[{pattern:/(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,lookbehind:!0,greedy:!0},{pattern:/(^|[^\\:])\/\/.*/,lookbehind:!0,greedy:!0}],string:{pattern:/(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,greedy:!0},"class-name":{pattern:/(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,lookbehind:!0,inside:{punctuation:/[.\\]/}},keyword:/\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,boolean:/\b(?:false|true)\b/,function:/\b\w+(?=\()/,number:/\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,operator:/[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,punctuation:/[{}[\];(),.:]/},n.languages.javascript=n.languages.extend(`clike`,{"class-name":[n.languages.clike[`class-name`],{pattern:/(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,lookbehind:!0}],keyword:[{pattern:/((?:^|\})\s*)catch\b/,lookbehind:!0},{pattern:/(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,lookbehind:!0}],function:/#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,number:{pattern:RegExp(`(^|[^\\w$])(?:NaN|Infinity|0[bB][01]+(?:_[01]+)*n?|0[oO][0-7]+(?:_[0-7]+)*n?|0[xX][\\dA-Fa-f]+(?:_[\\dA-Fa-f]+)*n?|\\d+(?:_\\d+)*n|(?:\\d+(?:_\\d+)*(?:\\.(?:\\d+(?:_\\d+)*)?)?|\\.\\d+(?:_\\d+)*)(?:[Ee][+-]?\\d+(?:_\\d+)*)?)(?![\\w$])`),lookbehind:!0},operator:/--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/}),n.languages.javascript[`class-name`][0].pattern=/(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/,n.languages.insertBefore(`javascript`,`keyword`,{regex:{pattern:RegExp(`((?:^|[^$\\w\\xA0-\\uFFFF."'\\])\\s]|\\b(?:return|yield))\\s*)\\/(?:(?:\\[(?:[^\\]\\\\\\r\\n]|\\\\.)*\\]|\\\\.|[^/\\\\\\[\\r\\n])+\\/[dgimyus]{0,7}|(?:\\[(?:[^[\\]\\\\\\r\\n]|\\\\.|\\[(?:[^[\\]\\\\\\r\\n]|\\\\.|\\[(?:[^[\\]\\\\\\r\\n]|\\\\.)*\\])*\\])*\\]|\\\\.|[^/\\\\\\[\\r\\n])+\\/[dgimyus]{0,7}v[dgimyus]{0,7})(?=(?:\\s|\\/\\*(?:[^*]|\\*(?!\\/))*\\*\\/)*(?:$|[\\r\\n,.;:})\\]]|\\/\\/))`),lookbehind:!0,greedy:!0,inside:{"regex-source":{pattern:/^(\/)[\s\S]+(?=\/[a-z]*$)/,lookbehind:!0,alias:`language-regex`,inside:n.languages.regex},"regex-delimiter":/^\/|\/$/,"regex-flags":/^[a-z]+$/}},"function-variable":{pattern:/#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,alias:`function`},parameter:[{pattern:/(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,lookbehind:!0,inside:n.languages.javascript},{pattern:/(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,lookbehind:!0,inside:n.languages.javascript},{pattern:/(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,lookbehind:!0,inside:n.languages.javascript},{pattern:/((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,lookbehind:!0,inside:n.languages.javascript}],constant:/\b[A-Z](?:[A-Z_]|\dx?)*\b/}),n.languages.insertBefore(`javascript`,`string`,{hashbang:{pattern:/^#!.*/,greedy:!0,alias:`comment`},"template-string":{pattern:/`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,greedy:!0,inside:{"template-punctuation":{pattern:/^`|`$/,alias:`string`},interpolation:{pattern:/((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,lookbehind:!0,inside:{"interpolation-punctuation":{pattern:/^\$\{|\}$/,alias:`punctuation`},rest:n.languages.javascript}},string:/[\s\S]+/}},"string-property":{pattern:/((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,lookbehind:!0,greedy:!0,alias:`property`}}),n.languages.insertBefore(`javascript`,`operator`,{"literal-property":{pattern:/((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,lookbehind:!0,alias:`property`}}),n.languages.markup&&(n.languages.markup.tag.addInlined(`script`,`javascript`),n.languages.markup.tag.addAttribute(`on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)`,`javascript`)),n.languages.js=n.languages.javascript,(function(){if(n===void 0||typeof document>`u`)return;Element.prototype.matches||(Element.prototype.matches=Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector);var e=`Loading…`,t=function(e,t){return`✖ Error `+e+` while fetching file: `+t},r=`✖ Error: File does not exist or is empty`,i={js:`javascript`,py:`python`,rb:`ruby`,ps1:`powershell`,psm1:`powershell`,sh:`bash`,bat:`batch`,h:`c`,tex:`latex`},a=`data-src-status`,o=`loading`,s=`loaded`,c=`failed`,l=`pre[data-src]:not([`+a+`="`+s+`"]):not([`+a+`="`+o+`"])`;function u(e,n,i){var a=new XMLHttpRequest;a.open(`GET`,e,!0),a.onreadystatechange=function(){a.readyState==4&&(a.status<400&&a.responseText?n(a.responseText):a.status>=400?i(t(a.status,a.statusText)):i(r))},a.send(null)}function d(e){var t=/^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(e||``);if(t){var n=Number(t[1]),r=t[2],i=t[3];return r?i?[n,Number(i)]:[n,void 0]:[n,n]}}n.hooks.add(`before-highlightall`,function(e){e.selector+=`, `+l}),n.hooks.add(`before-sanity-check`,function(t){var r=t.element;if(r.matches(l)){t.code=``,r.setAttribute(a,o);var f=r.appendChild(document.createElement(`CODE`));f.textContent=e;var p=r.getAttribute(`data-src`),m=t.language;if(m===`none`){var h=(/\.(\w+)$/.exec(p)||[,`none`])[1];m=i[h]||h}n.util.setLanguage(f,m),n.util.setLanguage(r,m);var g=n.plugins.autoloader;g&&g.loadLanguages(m),u(p,function(e){r.setAttribute(a,s);var t=d(r.getAttribute(`data-range`));if(t){var i=e.split(/\r\n?|\n/g),o=t[0],c=t[1]==null?i.length:t[1];o<0&&(o+=i.length),o=Math.max(0,Math.min(o-1,i.length)),c<0&&(c+=i.length),c=Math.max(0,Math.min(c,i.length)),e=i.slice(o,c).join(`
`),r.hasAttribute(`data-start`)||r.setAttribute(`data-start`,String(o+1))}f.textContent=e,n.highlightElement(f)},function(e){r.setAttribute(a,c),f.textContent=e})}}),n.plugins.fileHighlight={highlight:function(e){for(var t=(e||document).querySelectorAll(l),r=0,i;i=t[r++];)n.highlightElement(i)}};var f=!1;n.fileHighlight=function(){f||=(console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."),!0),n.plugins.fileHighlight.highlight.apply(this,arguments)}})()}))(),1);Prism.languages.c=Prism.languages.extend(`clike`,{comment:{pattern:/\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,greedy:!0},string:{pattern:/"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,greedy:!0},"class-name":{pattern:/(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,lookbehind:!0},keyword:/\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,function:/\b[a-z_]\w*(?=\s*\()/i,number:/(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,operator:/>>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/}),Prism.languages.insertBefore(`c`,`string`,{char:{pattern:/'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,greedy:!0}}),Prism.languages.insertBefore(`c`,`string`,{macro:{pattern:/(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,lookbehind:!0,greedy:!0,alias:`property`,inside:{string:[{pattern:/^(#\s*include\s*)<[^>]+>/,lookbehind:!0},Prism.languages.c.string],char:Prism.languages.c.char,comment:Prism.languages.c.comment,"macro-name":[{pattern:/(^#\s*define\s+)\w+\b(?!\()/i,lookbehind:!0},{pattern:/(^#\s*define\s+)\w+\b(?=\()/i,lookbehind:!0,alias:`function`}],directive:{pattern:/^(#\s*)[a-z]+/,lookbehind:!0,alias:`keyword`},"directive-hash":/^#/,punctuation:/##|\\(?=[\r\n])/,expression:{pattern:/\S[\s\S]*/,inside:Prism.languages.c}}}}),Prism.languages.insertBefore(`c`,`function`,{constant:/\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/}),delete Prism.languages.c.boolean,(function(e){var t=/\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/,n=`\\b(?!<keyword>)\\w+(?:\\s*\\.\\s*\\w+)*\\b`.replace(/<keyword>/g,function(){return t.source});e.languages.cpp=e.languages.extend(`c`,{"class-name":[{pattern:RegExp(`(\\b(?:class|concept|enum|struct|typename)\\s+)(?!<keyword>)\\w+`.replace(/<keyword>/g,function(){return t.source})),lookbehind:!0},/\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,/\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,/\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/],keyword:t,number:{pattern:/(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,greedy:!0},operator:/>>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,boolean:/\b(?:false|true)\b/}),e.languages.insertBefore(`cpp`,`string`,{module:{pattern:RegExp(`(\\b(?:import|module)\\s+)(?:"(?:\\\\(?:\\r\\n|[\\s\\S])|[^"\\\\\\r\\n])*"|<[^<>\\r\\n]*>|`+`<mod-name>(?:\\s*:\\s*<mod-name>)?|:\\s*<mod-name>`.replace(/<mod-name>/g,function(){return n})+`)`),lookbehind:!0,greedy:!0,inside:{string:/^[<"][\s\S]+/,operator:/:/,punctuation:/\./}},"raw-string":{pattern:/R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,alias:`string`,greedy:!0}}),e.languages.insertBefore(`cpp`,`keyword`,{"generic-function":{pattern:/\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,inside:{function:/^\w+/,generic:{pattern:/<[\s\S]+/,alias:`class-name`,inside:e.languages.cpp}}}}),e.languages.insertBefore(`cpp`,`operator`,{"double-colon":{pattern:/::/,alias:`punctuation`}}),e.languages.insertBefore(`cpp`,`class-name`,{"base-clause":{pattern:/(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,lookbehind:!0,greedy:!0,inside:e.languages.extend(`cpp`,{})}}),e.languages.insertBefore(`inside`,`double-colon`,{"class-name":/\b[a-z_]\w*\b(?!\s*::)/i},e.languages.cpp[`base-clause`])})(Prism),(function(e){var t=/\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/,n=`(?:[a-z]\\w*\\s*\\.\\s*)*(?:[A-Z]\\w*\\s*\\.\\s*)*`,r={pattern:RegExp(`(^|[^\\w.])`+n+`[A-Z](?:[\\d_A-Z]*[a-z]\\w*)?\\b`),lookbehind:!0,inside:{namespace:{pattern:/^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,inside:{punctuation:/\./}},punctuation:/\./}};e.languages.java=e.languages.extend(`clike`,{string:{pattern:/(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,lookbehind:!0,greedy:!0},"class-name":[r,{pattern:RegExp(`(^|[^\\w.])`+n+`[A-Z]\\w*(?=\\s+\\w+\\s*[;,=()]|\\s*(?:\\[[\\s,]*\\]\\s*)?::\\s*new\\b)`),lookbehind:!0,inside:r.inside},{pattern:RegExp(`(\\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\\s+)`+n+`[A-Z]\\w*\\b`),lookbehind:!0,inside:r.inside}],keyword:t,function:[e.languages.clike.function,{pattern:/(::\s*)[a-z_]\w*/,lookbehind:!0}],number:/\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,operator:{pattern:/(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,lookbehind:!0},constant:/\b[A-Z][A-Z_\d]+\b/}),e.languages.insertBefore(`java`,`string`,{"triple-quoted-string":{pattern:/"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,greedy:!0,alias:`string`},char:{pattern:/'(?:\\.|[^'\\\r\n]){1,6}'/,greedy:!0}}),e.languages.insertBefore(`java`,`class-name`,{annotation:{pattern:/(^|[^.])@\w+(?:\s*\.\s*\w+)*/,lookbehind:!0,alias:`punctuation`},generics:{pattern:/<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,inside:{"class-name":r,keyword:t,punctuation:/[<>(),.:]/,operator:/[?&|]/}},import:[{pattern:RegExp(`(\\bimport\\s+)`+n+`(?:[A-Z]\\w*|\\*)(?=\\s*;)`),lookbehind:!0,inside:{namespace:r.inside.namespace,punctuation:/\./,operator:/\*/,"class-name":/\w+/}},{pattern:RegExp(`(\\bimport\\s+static\\s+)`+n+`(?:\\w+|\\*)(?=\\s*;)`),lookbehind:!0,alias:`static`,inside:{namespace:r.inside.namespace,static:/\b\w+$/,punctuation:/\./,operator:/\*/,"class-name":/\w+/}}],namespace:{pattern:RegExp(`(\\b(?:exports|import(?:\\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\\s+)(?!<keyword>)[a-z]\\w*(?:\\.[a-z]\\w*)*\\.?`.replace(/<keyword>/g,function(){return t.source})),lookbehind:!0,inside:{punctuation:/\./}}})})(Prism),Prism.languages.python={comment:{pattern:/(^|[^\\])#.*/,lookbehind:!0,greedy:!0},"string-interpolation":{pattern:/(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,greedy:!0,inside:{interpolation:{pattern:/((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,lookbehind:!0,inside:{"format-spec":{pattern:/(:)[^:(){}]+(?=\}$)/,lookbehind:!0},"conversion-option":{pattern:/![sra](?=[:}]$)/,alias:`punctuation`},rest:null}},string:/[\s\S]+/}},"triple-quoted-string":{pattern:/(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,greedy:!0,alias:`string`},string:{pattern:/(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,greedy:!0},function:{pattern:/((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,lookbehind:!0},"class-name":{pattern:/(\bclass\s+)\w+/i,lookbehind:!0},decorator:{pattern:/(^[\t ]*)@\w+(?:\.\w+)*/m,lookbehind:!0,alias:[`annotation`,`punctuation`],inside:{punctuation:/\./}},keyword:/\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,builtin:/\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,boolean:/\b(?:False|None|True)\b/,number:/\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,operator:/[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,punctuation:/[{}[\];(),.:]/},Prism.languages.python[`string-interpolation`].inside.interpolation.inside.rest=Prism.languages.python,Prism.languages.py=Prism.languages.python;function l(e){let t=document.createElement(`div`);t.id=`pta-confirm-dialog`,t.style.position=`fixed`,t.style.top=`0`,t.style.left=`0`,t.style.width=`100%`,t.style.height=`100%`,t.style.background=`rgba(0, 0, 0, 0.5)`,t.style.display=`flex`,t.style.justifyContent=`center`,t.style.alignItems=`center`,t.style.zIndex=`999999`,t.style.backdropFilter=`blur(2px)`;let n=document.createElement(`div`);n.style.background=`white`,n.style.borderRadius=`6px`,n.style.boxShadow=`0 4px 20px rgba(0, 0, 0, 0.15)`,n.style.width=`400px`,n.style.maxWidth=`90%`,n.style.overflow=`hidden`;let r=document.createElement(`div`);r.style.padding=`16px`,r.style.borderBottom=`1px solid #e0e0e0`,r.style.display=`flex`,r.style.justifyContent=`space-between`,r.style.alignItems=`center`;let i=document.createElement(`div`);i.style.fontSize=`16px`,i.style.fontWeight=`bold`,i.style.color=`#333`,i.textContent=e.header||`确认`;let a=document.createElement(`button`);a.style.background=`none`,a.style.border=`none`,a.style.fontSize=`20px`,a.style.cursor=`pointer`,a.style.color=`#666`,a.textContent=`×`,a.addEventListener(`click`,()=>{e.reject&&e.reject(),document.body.removeChild(t)}),r.appendChild(i),r.appendChild(a);let o=document.createElement(`div`);o.style.padding=`20px`;let s=document.createElement(`div`);s.style.fontSize=`14px`,s.style.color=`#333`,s.style.lineHeight=`1.5`,s.textContent=e.message,o.appendChild(s);let c=document.createElement(`div`);c.style.padding=`16px`,c.style.borderTop=`1px solid #e0e0e0`,c.style.display=`flex`,c.style.justifyContent=`flex-end`,c.style.gap=`10px`;let l=document.createElement(`button`);l.style.padding=`8px 16px`,l.style.border=`1px solid #ddd`,l.style.borderRadius=`4px`,l.style.background=`white`,l.style.color=`#333`,l.style.cursor=`pointer`,l.style.fontSize=`14px`,l.textContent=`取消`,l.addEventListener(`click`,()=>{e.reject&&e.reject(),document.body.removeChild(t)});let u=document.createElement(`button`);u.style.padding=`8px 16px`,u.style.border=`none`,u.style.borderRadius=`4px`,u.style.background=`#4CAF50`,u.style.color=`white`,u.style.cursor=`pointer`,u.style.fontSize=`14px`,u.textContent=`确认`,u.addEventListener(`click`,async()=>{e.accept&&await e.accept(),document.body.removeChild(t)}),c.appendChild(l),c.appendChild(u),n.appendChild(r),n.appendChild(o),n.appendChild(c),t.appendChild(n),document.body.appendChild(t),t.addEventListener(`click`,n=>{n.target===t&&(e.reject&&e.reject(),document.body.removeChild(t))})}function u(e,t=`info`){let n=document.getElementById(`pta-toast-container`);n||(n=document.createElement(`div`),n.id=`pta-toast-container`,n.style.position=`fixed`,n.style.top=`20px`,n.style.right=`20px`,n.style.zIndex=`999999`,n.style.display=`flex`,n.style.flexDirection=`column`,n.style.gap=`10px`,document.body.appendChild(n));let r=document.createElement(`div`);switch(r.style.padding=`12px 16px`,r.style.borderRadius=`4px`,r.style.color=`white`,r.style.fontSize=`14px`,r.style.fontWeight=`500`,r.style.boxShadow=`0 4px 12px rgba(0,0,0,0.15)`,r.style.transition=`all 0.3s ease`,r.style.opacity=`0`,r.style.transform=`translateX(100%)`,t){case`success`:r.style.backgroundColor=`#4CAF50`;break;case`error`:r.style.backgroundColor=`#f44336`;break;case`warning`:r.style.backgroundColor=`#ff9800`;break;default:r.style.backgroundColor=`#2196F3`}r.textContent=e,n.appendChild(r),setTimeout(()=>{r.style.opacity=`1`,r.style.transform=`translateX(0)`},10),setTimeout(()=>{r.style.opacity=`0`,r.style.transform=`translateX(100%)`,setTimeout(()=>{r.parentNode&&r.parentNode.removeChild(r)},300)},3e3)}var d={autoPopup:!0,extractDelay:2e3,language:`c`,aiEnabled:!1,aiApiKey:``,aiApiUrl:`https://api.openai.com/v1`,aiModel:`gpt-3.5-turbo`,aiSystemPrompt:`你是专业的编程题 AC 生成器。
语言：{language}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。

以下是题目内容：
{problem content}`,aiErrorPrompt:`你是专业的编程题 AC 生成器。
语言：{language}
错误类型：{error_type}
编译器提示：{compiler_msg}
测试点提示提示：{data_tip}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。
题目如下：
{problem content}
错误源码如下：
{res_code}`},f=``,p=null,m=[];function h(e){chrome.storage.local.get(Object.keys(d),function(t){e({...d,...t})})}function g(){h(function(e){if(e.autoPopup){let e=y()||S(),t=x();e?(j(),D(),setTimeout(()=>{b()?_():S()&&C()},100)):t?v():j()}else j()})}function _(){h(function(e){setTimeout(async()=>{await w()},e.extractDelay)})}function v(){h(function(e){setTimeout(async()=>{await L()},e.extractDelay)})}function y(){let e=window.location.href;return/\/problem-sets\/.+\/exam\/problems\/.+/.test(e)}function b(){let e=window.location.href;return/problemSetProblemId=\d+/.test(e)}function x(){let e=window.location.href;return e.includes(`/problem-sets/`)&&e.includes(`/exam/submissions/`)}function S(){let e=window.location.href;return/\/problem-sets\/.+\/exam\/problems\/type\/\d+/.test(e)&&!/problemSetProblemId=\d+/.test(e)}async function C(){if(!S())return;let e=document.getElementById(`pta-problem-list`),t=document.getElementById(`pta-problem-list-status`);if(e)try{let n=window.location.href.match(/\/problem-sets\/(\d+)/);if(!n){u(`无法从URL中提取problemSetId`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取题目列表</span></div>`;return}let r=n[1],i=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!i.ok){u(`获取examId失败: ${i.status}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取examId</span></div>`;return}let a=(await i.json()).exam?.id;if(!a){u(`无法获取examId`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">无法获取examId</span></div>`;return}let o=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problem-list?exam_id=${a}&problem_type=PROGRAMMING&page=0&limit=100`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!o.ok){u(`获取题目列表失败: ${o.status}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">获取题目列表失败</span></div>`;return}let s=await o.json(),c=s.examLabelByProblemSetProblemId||{};if(s.problemSetProblems){let n=``;s.problemSetProblems.forEach((e,t)=>{let r=c[e.id]||`${t+1}`;n+=`<div class="problem-item" data-id="${e.id}">
          <span class="problem-index">${r}</span>
          <span class="problem-title">${e.title}</span>
          <button class="problem-action-btn">一键完成</button>
        </div>`}),e.innerHTML=n,t&&(t.textContent=`共 ${s.problemSetProblems.length} 道题目`,t.className=`success`),e.querySelectorAll(`.problem-item`).forEach(e=>{e.addEventListener(`click`,function(e){if(e.target.classList.contains(`problem-action-btn`))return;let t=this.getAttribute(`data-id`);this.querySelector(`.problem-title`).textContent,window.open(`https://pintia.cn/problem-sets/${r}/exam/problems/type/7?problemSetProblemId=${t}`,`_blank`)});let t=e.querySelector(`.problem-action-btn`);t&&t.addEventListener(`click`,async function(){let n=e.getAttribute(`data-id`);e.querySelector(`.problem-title`).textContent,t.disabled=!0,t.textContent=`处理中...`;try{let e=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!e.ok)throw Error(`获取examId失败`);let i=(await e.json()).exam?.id;if(!i)throw Error(`无法获取examId`);let a=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problems/${n}`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!a.ok)throw Error(`获取题目内容失败`);let o=await a.json(),s=``;if(o&&o.problemSetProblem&&(s=o.problemSetProblem.content||o.problemSetProblem.description||``),!s)throw Error(`未提取到题目内容`);let c=await new Promise(e=>{h(e)});if(!c.aiEnabled||!c.aiApiKey)throw Error(`AI 未启用或未配置 API 密钥`);let l=c.aiApiKey,u=c.aiApiUrl,d=c.aiModel,f=c.aiSystemPrompt,p=c.language;f=f.replace(`{language}`,p).replace(`{problem content}`,s);let m=[{role:`system`,content:f},{role:`user`,content:``}],g=await fetch(`${u}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${l}`},body:JSON.stringify({model:d,messages:m,temperature:.7})});if(!g.ok){let e=await g.json();throw Error(`AI 调用失败: `+(e.message||`未知错误`))}let _=await g.json();if(!_.choices||_.choices.length===0)throw Error(`AI 未返回有效结果`);let v=_.choices[0].message.content;v=v.replace(/```[\w]*\n?/g,``).trim();let y=`https://pintia.cn/api/exams/${i}/exam-submissions`,b={problemType:`PROGRAMMING`,details:[{problemId:`0`,problemSetProblemId:n,programmingSubmissionDetail:{program:v,compiler:`GCC`}}]},x=await fetch(y,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},body:JSON.stringify(b),method:`POST`,credentials:`include`});if(!x.ok){let e=await x.json();throw Error(`提交失败: `+(e.message||`未知错误`))}t.textContent=`完成`,t.style.background=`#2196F3`,t.disabled=!1}catch(e){u(`一键完成出现错误: ${e.message}`,`error`),t.textContent=`错误`,t.style.background=`#f44336`,setTimeout(()=>{t.textContent=`一键完成`,t.style.background=`#4CAF50`,t.disabled=!1},2e3)}})});let i=document.getElementById(`pta-complete-all-btn`),a=document.getElementById(`pta-complete-all-status`);i&&i.addEventListener(`click`,async function(){l({message:`确定要一键完成所有题目吗？这将自动处理当前列表中的所有题目。`,header:`确认操作`,icon:`pi pi-exclamation-triangle`,accept:async()=>{i.disabled=!0,i.textContent=`处理中...`,a.style.display=`block`,a.className=`processing`,a.textContent=`正在处理题目...`;try{let t=s.problemSetProblems,n=0,o=0,c=await fetch(`https://pintia.cn/api/problem-sets/${r}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!c.ok)throw Error(`获取examId失败`);let l=(await c.json()).exam?.id;if(!l)throw Error(`无法获取examId`);let d=await new Promise(e=>{h(e)});if(!d.aiEnabled||!d.aiApiKey)throw Error(`AI 未启用或未配置 API 密钥`);a.textContent=`正在处理 ${t.length} 道题目...`;let f=[],p=async(t,n)=>{let i=t.id,a=t.title;try{let t=await fetch(`https://pintia.cn/api/problem-sets/${r}/exam-problems/${i}`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!t.ok)throw Error(`获取题目内容失败`);let n=await t.json(),a=``;if(n&&n.problemSetProblem&&(a=n.problemSetProblem.content||n.problemSetProblem.description||``),!a)throw Error(`未提取到题目内容`);let o=d.aiApiKey,s=d.aiApiUrl,c=d.aiModel,u=d.aiSystemPrompt,f=d.language;u=u.replace(`{language}`,f).replace(`{problem content}`,a);let p=[{role:`system`,content:u},{role:`user`,content:``}],m=await fetch(`${s}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${o}`},body:JSON.stringify({model:c,messages:p,temperature:.7})});if(!m.ok){let e=await m.json();throw Error(`AI 调用失败: `+(e.message||`未知错误`))}let h=await m.json();if(!h.choices||h.choices.length===0)throw Error(`AI 未返回有效结果`);let g=h.choices[0].message.content;g=g.replace(/```[\w]*\n?/g,``).trim();let _=`https://pintia.cn/api/exams/${l}/exam-submissions`,v={problemType:`PROGRAMMING`,details:[{problemId:`0`,problemSetProblemId:i,programmingSubmissionDetail:{program:g,compiler:`GCC`}}]},y=await fetch(_,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},body:JSON.stringify(v),method:`POST`,credentials:`include`});if(!y.ok){let e=await y.json();throw Error(`提交失败: `+(e.message||`未知错误`))}let b=e.querySelector(`.problem-item[data-id="${i}"]`);if(b){let e=b.querySelector(`.problem-action-btn`);e&&(e.textContent=`完成`,e.style.background=`#2196F3`,e.disabled=!1)}return!0}catch(t){u(`处理题目 ${a} 失败: ${t.message}`,`error`);let n=e.querySelector(`.problem-item[data-id="${i}"]`);if(n){let e=n.querySelector(`.problem-action-btn`);e&&(e.textContent=`失败`,e.style.background=`#f44336`,setTimeout(()=>{e.textContent=`一键完成`,e.style.background=`#4CAF50`,e.disabled=!1},2e3))}return!1}};for(let e=0;e<t.length;e++){let n=new Promise(t=>{setTimeout(t,e*500)}).then(()=>p(t[e],e));f.push(n)}let m=await Promise.all(f);n=m.filter(e=>e).length,o=m.filter(e=>!e).length,a.className=`success`,a.textContent=`处理完成！成功: ${n}, 失败: ${o}`,i.textContent=`完成所有题目`,i.disabled=!1}catch(e){u(`一键完成所有题目失败: ${e.message}`,`error`),a.className=`error`,a.textContent=`处理失败: `+e.message,i.textContent=`一键完成所有题目`,i.disabled=!1}},reject:()=>{}})})}}catch(n){u(`获取题目列表出错: ${n.message}`,`error`),e.innerHTML=`<div class="problem-item"><span class="problem-index">错误</span><span class="problem-title">获取题目列表出错</span></div>`,t&&(t.textContent=`获取题目列表出错`,t.className=`error`)}}async function w(){if(!b())return null;try{let e=window.location.href,t=e.match(/\/problem-sets\/(\d+)/),n=e.match(/problemSetProblemId=(\d+)/);if(!t||!n)return u(`无法从URL中提取问题集ID或问题ID`,`error`),null;let r=`https://pintia.cn/api/problem-sets/${t[1]}/exam-problems/${n[1]}`,i=await fetch(r,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,priority:`u=1, i`,"sec-ch-ua":`"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"`,"sec-ch-ua-mobile":`?0`,"sec-ch-ua-platform":`"Windows"`,"sec-fetch-dest":`empty`,"sec-fetch-mode":`cors`,"sec-fetch-site":`same-origin`,"x-lollipop":N(),"x-marshmallow":``},referrer:e,body:null,method:`GET`,mode:`cors`,credentials:`include`});if(!i.ok)return u(`API请求失败: ${i.status} ${i.statusText}`,`error`),null;let a=await i.json(),o=``;return a&&a.problemSetProblem&&(a.problemSetProblem.content?o=a.problemSetProblem.content:a.problemSetProblem.description&&(o=a.problemSetProblem.description)),f=o,m=[],T(f),a}catch(e){return u(`获取题目数据时出错: ${e.message}`,`error`),null}}async function T(e,t=!1,n=``){h(async function(r){if(!r.aiEnabled)return;let i=r.aiApiKey,a=r.aiApiUrl,o=r.aiModel,s=r.aiSystemPrompt,c=r.language;if(!i){u(`未配置 API 密钥`,`warning`);return}s=s.replace(`{language}`,c).replace(`{problem content}`,e);let l=[{role:`system`,content:s}];m.length>0&&(l=l.concat(m));let d=``;d=t&&n?`之前的代码有误，错误信息：${n}\n\n请重新思考并修正代码。`:t?`之前的代码有误，请重新思考并修正代码。`:``,l.push({role:`user`,content:d});try{let e=await fetch(`${a}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${i}`},body:JSON.stringify({model:o,messages:l,temperature:.7})});if(!e.ok){u(`AI 调用失败：${(await e.json()).message||`未知错误`}`,`error`);return}let t=(await e.json()).choices[0].message.content;m.push({role:`user`,content:d}),m.push({role:`assistant`,content:t}),E(t)}catch(e){u(`AI 调用出错：${e.message}`,`error`)}})}function E(e){let t=document.getElementById(`pta-code-input`),n=document.getElementById(`pta-code-highlight`);if(t&&n){let r=e.replace(/```[\w]*\n?/g,``).trim();t.value=r,n.textContent=r,c.default.highlightElement(n)}}function D(){if(document.getElementById(`pta-helper-float`))return;let e=document.createElement(`div`);e.id=`pta-helper-float`,S()?e.innerHTML=k():e.innerHTML=O();let t=document.createElement(`style`);t.textContent=`
    #pta-helper-float {
      position: fixed;
      top: 50px;
      right: 20px;
      width: 500px;
      max-height: 80vh;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: Arial, sans-serif;
      overflow-y: auto;
    }
    .pta-float-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: #4CAF50;
      color: white;
      border-radius: 8px 8px 0 0;
      cursor: move;
      position: sticky;
      top: 0;
      z-index: 1;
    }
    .pta-float-header span {
      font-weight: bold;
      font-size: 16px;
    }
    .pta-float-close {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pta-float-close:hover {
      background: rgba(255,255,255,0.2);
      border-radius: 4px;
    }
    .pta-float-body {
      padding: 20px;
    }
    .code-editor-container {
      position: relative;
      width: 100%;
      height: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
      overflow: hidden;
    }
    .code-editor-container pre {
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      padding: 12px;
      width: 100%;
      height: 100%;
      background: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      overflow: hidden;
      pointer-events: none;
    }
    .code-editor-container code {
      font-family: 'Courier New', monospace;
    }
    #pta-code-input {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      padding: 12px;
      border: none;
      background: transparent;
      color: transparent;
      caret-color: #333;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      resize: none;
      box-sizing: border-box;
      z-index: 1;
    }
    #pta-code-input:focus {
      outline: none;
    }
    .pta-buttons {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }
    #pta-submit-btn, #pta-report-error-btn {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    #pta-submit-btn {
      background: #4CAF50;
      color: white;
    }
    #pta-submit-btn:hover {
      background: #45a049;
    }
    #pta-submit-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-report-error-btn {
      background: #ff9800;
      color: white;
    }
    #pta-report-error-btn:hover {
      background: #f57c00;
    }
    .error-section {
      margin-top: 15px;
      padding: 15px;
      background: #fff3e0;
      border-radius: 4px;
      border: 1px solid #ffcc80;
    }
    #pta-error-note {
      width: 100%;
      height: 80px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      resize: vertical;
      font-family: Arial, sans-serif;
      font-size: 13px;
      box-sizing: border-box;
    }
    .btn-retry {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      background: #f44336;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    .btn-retry:hover {
      background: #d32f2f;
    }
    #pta-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-status.error {
      color: #f44336;
      background: #ffebee;
    }
    .problem-list {
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .problem-item {
      display: flex;
      padding: 10px 12px;
      border-bottom: 1px solid #eee;
      cursor: pointer;
    }
    .problem-item:last-child {
      border-bottom: none;
    }
    .problem-item:hover {
      background: #f5f5f5;
    }
    .problem-index {
      font-weight: bold;
      color: #4CAF50;
      margin-right: 12px;
      min-width: 60px;
    }
    .problem-title {
      color: #333;
      flex: 1;
    }
    .problem-action-btn {
      background: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      white-space: nowrap;
    }
    .problem-action-btn:hover {
      background: #45a049;
    }
    .problem-action-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    .btn-complete-all {
      width: 100%;
      padding: 10px;
      background: #2196F3;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 15px;
    }
    .btn-complete-all:hover {
      background: #1976D2;
    }
    .btn-complete-all:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-problem-list-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-complete-all-status {
      margin-top: 10px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-complete-all-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-complete-all-status.error {
      color: #f44336;
      background: #ffebee;
    }
    #pta-complete-all-status.processing {
      color: #2196F3;
      background: #e3f2fd;
    }
  `,document.head.appendChild(t),document.body.appendChild(e),e.querySelector(`.pta-float-close`).addEventListener(`click`,()=>{e.remove()}),S()||A(e),M(e)}function O(){return`
    <div class="pta-float-header">
      <span>PTA 答题辅助</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="code-editor-container">
        <pre><code id="pta-code-highlight" class="language-c"></code></pre>
        <textarea id="pta-code-input" placeholder="请输入代码..."></textarea>
      </div>
      <div class="pta-buttons">
        <button id="pta-submit-btn">提交代码</button>
        <button id="pta-report-error-btn" class="btn-secondary">答案报错</button>
      </div>
      <div id="pta-error-section" class="error-section" style="display: none;">
        <textarea id="pta-error-note" placeholder="请输入错误备注（可选）..."></textarea>
        <button id="pta-retry-btn" class="btn-retry">重新生成</button>
      </div>
      <div id="pta-status"></div>
    </div>
  `}function k(){return`
    <div class="pta-float-header">
      <span>PTA 答题辅助 - 题目列表</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="pta-buttons">
        <button id="pta-complete-all-btn" class="btn-complete-all">一键完成所有题目</button>
      </div>
      <div id="pta-problem-list" class="problem-list">
        <div class="problem-item">
          <span class="problem-index">加载中...</span>
          <span class="problem-title">正在获取题目列表...</span>
        </div>
      </div>
      <div id="pta-problem-list-status"></div>
      <div id="pta-complete-all-status" style="display: none;"></div>
    </div>
  `}function A(e){let t=e.querySelector(`#pta-code-input`),n=e.querySelector(`#pta-code-highlight`);t.addEventListener(`input`,function(){n.textContent=t.value,c.default.highlightElement(n)}),t.addEventListener(`scroll`,function(){n.parentElement.scrollTop=t.scrollTop,n.parentElement.scrollLeft=t.scrollLeft});let r=e.querySelector(`#pta-submit-btn`),i=e.querySelector(`#pta-status`);r.addEventListener(`click`,async()=>{let e=t.value.trim();if(!e){i.textContent=`请输入代码`,i.className=`error`;return}r.disabled=!0,i.textContent=`提交中...`,i.className=``;let n=await P(e);r.disabled=!1,n.success?(i.textContent=`提交成功！`,i.className=`success`):(i.textContent=n.error||`提交失败`,i.className=`error`)});let a=e.querySelector(`#pta-report-error-btn`),o=e.querySelector(`#pta-error-section`);a.addEventListener(`click`,()=>{o.style.display=o.style.display===`none`?`block`:`none`});let s=e.querySelector(`#pta-retry-btn`),l=e.querySelector(`#pta-error-note`);s.addEventListener(`click`,async()=>{let e=l.value.trim();s.disabled=!0,s.textContent=`重新生成中...`,i.textContent=`正在重新生成代码...`,i.className=``,await T(f,!0,e),s.disabled=!1,s.textContent=`重新生成`,i.textContent=`代码已重新生成！`,i.className=`success`,o.style.display=`none`,l.value=``})}function j(){let e=document.getElementById(`pta-helper-float`);e&&e.remove()}function M(e){let t=e.querySelector(`.pta-float-header`),n=!1,r,i,a,o,s=0,c=0;t.addEventListener(`mousedown`,l),document.addEventListener(`mouseup`,u),document.addEventListener(`mousemove`,d);function l(e){a=e.clientX-s,o=e.clientY-c,(e.target===t||e.target.tagName===`SPAN`)&&(n=!0)}function u(){a=r,o=i,n=!1}function d(t){n&&(t.preventDefault(),r=t.clientX-a,i=t.clientY-o,s=r,c=i,e.style.transform=`translate(${r}px, ${i}px)`)}}function N(){let e=localStorage.getItem(`x-lollipop`)||``;if(!e){let t=document.cookie.match(/x-lollipop=([^;]+)/);t&&(e=t[1])}return e}async function P(e){try{let t=window.location.href,n=t.match(/problemSetProblemId=(\d+)/),r=n?n[1]:null,i=t.match(/\/problem-sets\/(\d+)/),a=i?i[1]:null;if(!r||!a)return{success:!1,error:`无法获取页面信息`};let o=null,s=await fetch(`https://pintia.cn/api/problem-sets/${a}/exams`,{headers:{accept:`application/json;charset=UTF-8`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(s.ok){let e=await s.json();e&&e.exam&&e.exam.id&&(o=e.exam.id)}if(!o)return{success:!1,error:`无法获取 exam ID`};let c=`https://pintia.cn/api/exams/${o}/exam-submissions`,l={problemType:`PROGRAMMING`,details:[{problemId:`0`,problemSetProblemId:r,programmingSubmissionDetail:{program:e,compiler:`GCC`}}]},u=await fetch(c,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},referrer:t,body:JSON.stringify(l),method:`POST`,mode:`cors`,credentials:`include`}),d=await u.json();return u.ok?{success:!0,data:d}:{success:!1,error:d.message||`提交失败`}}catch(e){return{success:!1,error:e.message}}}var F=window.location.href;setInterval(()=>{I()},1e3),window.addEventListener(`popstate`,function(){I()}),window.addEventListener(`hashchange`,function(){I()});function I(){if(window.location.href!==F&&(F=window.location.href,g(),!x())){let e=document.getElementById(`pta-helper-result-float`);e&&e.remove()}}window.addEventListener(`load`,function(){I()}),g();async function L(){if(!x())return null;try{let e=window.location.href,t=e.match(/\/exam\/submissions\/(\d+)/);if(!t)return u(`无法从URL中提取提交ID`,`error`),null;let n=`https://pintia.cn/api/submissions/${t[1]}?`,r=await fetch(n,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,priority:`u=1, i`,"sec-ch-ua":`"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"`,"sec-ch-ua-mobile":`?0`,"sec-ch-ua-platform":`"Windows"`,"sec-fetch-dest":`empty`,"sec-fetch-mode":`cors`,"sec-fetch-site":`same-origin`,"x-lollipop":N(),"x-marshmallow":``},referrer:e,body:null,method:`GET`,mode:`cors`,credentials:`include`});if(!r.ok)return u(`API请求失败: ${r.status} ${r.statusText}`,`error`),null;let i=await r.json();return p=i,R(),i}catch(e){return u(`获取提交结果数据时出错: ${e.message}`,`error`),null}}function R(){if(document.getElementById(`pta-helper-result-float`))return;let e=document.createElement(`div`);e.id=`pta-helper-result-float`,e.innerHTML=`
    <div class="pta-float-header">
      <span>PTA 答题辅助 - 结果分析</span>
      <button class="pta-float-close">×</button>
    </div>
    <div class="pta-float-body">
      <div class="pta-result-info">
        <div id="pta-result-status"></div>
      </div>
      <div class="pta-buttons">
        <button id="pta-get-answer-btn">获取答案</button>
      </div>
      <div id="pta-ai-result" style="display: none;">
        <h4>AI 生成的答案</h4>
        <div class="code-editor-container">
          <pre><code id="pta-ai-code-highlight" class="language-c"></code></pre>
          <textarea id="pta-ai-code" placeholder="AI 生成的代码将显示在这里..." readonly></textarea>
        </div>
        <div class="pta-buttons">
          <button id="pta-copy-btn">一键复制</button>
        </div>
      </div>
      <div id="pta-status"></div>
    </div>
  `;let t=document.createElement(`style`);t.textContent=`
    #pta-helper-result-float {
      position: fixed;
      top: 50px;
      right: 20px;
      width: 500px;
      max-height: 80vh;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: Arial, sans-serif;
      overflow-y: auto;
    }
    .pta-float-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: #4CAF50;
      color: white;
      border-radius: 8px 8px 0 0;
      cursor: move;
      position: sticky;
      top: 0;
      z-index: 1;
    }
    .pta-float-header span {
      font-weight: bold;
      font-size: 16px;
    }
    .pta-float-close {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pta-float-close:hover {
      background: rgba(255,255,255,0.2);
      border-radius: 4px;
    }
    .pta-float-body {
      padding: 20px;
    }
    .pta-result-info {
      margin-bottom: 20px;
    }
    #pta-result-status {
      font-size: 14px;
      line-height: 1.5;
    }
    .pta-buttons {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }
    #pta-get-answer-btn, #pta-copy-btn {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    #pta-get-answer-btn {
      background: #4CAF50;
      color: white;
    }
    #pta-get-answer-btn:hover {
      background: #45a049;
    }
    #pta-get-answer-btn:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    #pta-copy-btn {
      background: #2196F3;
      color: white;
    }
    #pta-copy-btn:hover {
      background: #1976D2;
    }
    #pta-ai-result {
      margin-top: 20px;
    }
    #pta-ai-result h4 {
      margin-top: 0;
      margin-bottom: 10px;
      color: #333;
    }
    .code-editor-container {
      position: relative;
      width: 100%;
      height: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
      overflow: hidden;
    }
    .code-editor-container pre {
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      padding: 12px;
      width: 100%;
      height: 100%;
      background: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      overflow: auto;
      pointer-events: none;
    }
    .code-editor-container code {
      font-family: 'Courier New', monospace;
    }
    #pta-ai-code {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      padding: 12px;
      border: none;
      background: transparent;
      color: transparent;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      line-height: 1.5;
      resize: none;
      box-sizing: border-box;
      z-index: 1;
    }
    #pta-status {
      margin-top: 15px;
      font-size: 13px;
      text-align: center;
      min-height: 20px;
      padding: 8px;
      border-radius: 4px;
    }
    #pta-status.success {
      color: #4CAF50;
      background: #e8f5e9;
    }
    #pta-status.error {
      color: #f44336;
      background: #ffebee;
    }
  `,document.head.appendChild(t),document.body.appendChild(e);let n=e.querySelector(`#pta-ai-code`),r=e.querySelector(`#pta-ai-code-highlight`);n.addEventListener(`scroll`,function(){r.parentElement.scrollTop=n.scrollTop,r.parentElement.scrollLeft=n.scrollLeft}),e.querySelector(`.pta-float-close`).addEventListener(`click`,()=>{e.remove()});let i=e.querySelector(`#pta-get-answer-btn`),a=e.querySelector(`#pta-ai-result`),o=e.querySelector(`#pta-status`);i.addEventListener(`click`,async()=>{if(!p){o.textContent=`未找到提交结果数据`,o.className=`error`;return}i.disabled=!0,i.textContent=`获取中...`,o.textContent=`正在获取答案...`,o.className=``;try{let e=``,t=``,s=``,l=``;if(p&&p.submission&&p.submission.submissionDetails&&p.submission.submissionDetails.length>0){let t=p.submission.submissionDetails[0];t.programmingSubmissionDetail&&t.programmingSubmissionDetail.program&&(e=t.programmingSubmissionDetail.program)}if(p&&p.submission&&p.submission.status&&(t=p.submission.status),p&&p.submission&&p.submission.judgeResponseContents&&p.submission.judgeResponseContents.length>0){let e=p.submission.judgeResponseContents[0];e.programmingJudgeResponseContent&&e.programmingJudgeResponseContent.compilationResult&&(s=e.programmingJudgeResponseContent.compilationResult.log||``)}if(p&&p.submission){let e=p.submission.hints||{},t=p.submission.judgeResponseContents&&p.submission.judgeResponseContents.length>0&&p.submission.judgeResponseContents[0].programmingJudgeResponseContent.testcaseJudgeResults||{},n=[];for(let r in e)if(e.hasOwnProperty(r)){let i={序号:r,提示:e[r],结果:t[r]?t[r].result:`未知`};n.push(i)}l=JSON.stringify(n,null,2)}let u=p.submission.problemSetProblemId,d=p.submission.problemSetId;if(!u||!d){o.textContent=`无法获取题目信息`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let f=`https://pintia.cn/api/problem-sets/${d}/exam-problems/${u}`,m=await fetch(f,{headers:{accept:`application/json;charset=UTF-8`,"accept-language":`zh-CN`,"content-type":`application/json;charset=UTF-8`,"x-lollipop":N(),"x-marshmallow":``},method:`GET`,credentials:`include`});if(!m.ok){o.textContent=`获取题目信息失败`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let g=await m.json(),_=``;g&&g.problemSetProblem&&(_=g.problemSetProblem.content||g.problemSetProblem.description||``),h(async function(u){if(!u.aiEnabled||!u.aiApiKey){o.textContent=`AI 未启用或未配置 API 密钥`,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let d=[{role:`system`,content:(u.aiErrorPrompt||`你是专业的编程题 AC 生成器。
语言：{language}
错误类型：{error_type}
编译器提示：{compiler_msg}
测试点提示：{data_tip}

请直接输出**能 AC 的完整代码**，不要解释、不要说明、不要多余内容。
严格遵守格式：换行、空格、缩进必须完全符合题目要求。
题目如下：
{problem content}
错误源码如下：
{res_code}`).replace(`{language}`,u.language).replace(`{error_type}`,t).replace(`{compiler_msg}`,s).replace(`{data_tip}`,l).replace(`{problem content}`,_).replace(`{res_code}`,e)}],f=await fetch(`${u.aiApiUrl}/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${u.aiApiKey}`},body:JSON.stringify({model:u.aiModel,messages:d,temperature:.7})});if(!f.ok){o.textContent=`AI 调用失败: `+((await f.json()).message||`未知错误`),o.className=`error`,i.disabled=!1,i.textContent=`获取答案`;return}let p=await f.json();if(p.choices&&p.choices.length>0){let e=p.choices[0].message.content;e=e.replace(/```[\w]*\n?/g,``).trim(),n.value=e,r.textContent=e,c.default.highlightElement(r),a.style.display=`block`,o.textContent=`答案获取成功！`,o.className=`success`}else o.textContent=`AI 未返回有效结果`,o.className=`error`;i.disabled=!1,i.textContent=`获取答案`})}catch(e){o.textContent=`获取答案时出错: `+e.message,o.className=`error`,i.disabled=!1,i.textContent=`获取答案`}}),e.querySelector(`#pta-copy-btn`).addEventListener(`click`,()=>{let e=n.value;if(!e){o.textContent=`没有可复制的代码`,o.className=`error`;return}navigator.clipboard.writeText(e).then(()=>{o.textContent=`代码已复制到剪贴板！`,o.className=`success`}).catch(e=>{o.textContent=`复制失败: `+e.message,o.className=`error`})}),M(e)}chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.action===`submitCode`)return P(e.code).then(e=>{n(e)}),!0;if(e.action===`extractProblem`)return w().then(()=>{n({success:!0})}).catch(e=>{n({success:!1,error:e.message})}),!0;if(e.action===`generateCode`)return f?T(f).then(()=>{n({success:!0})}).catch(e=>{n({success:!1,error:e.message})}):n({success:!1,error:`未提取到题目内容`}),!0;if(e.action===`autoSubmit`){let e=document.getElementById(`pta-code-input`);if(e){let t=e.value.trim();t?P(t).then(e=>{n(e)}):n({success:!1,error:`代码为空`})}else n({success:!1,error:`未找到代码输入框`});return!0}});})()
